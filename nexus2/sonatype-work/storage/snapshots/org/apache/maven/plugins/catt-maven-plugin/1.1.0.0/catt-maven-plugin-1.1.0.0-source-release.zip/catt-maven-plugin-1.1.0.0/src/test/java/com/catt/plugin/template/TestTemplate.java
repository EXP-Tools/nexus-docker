package com.catt.plugin.template;

public class TestTemplate {

	//TODO
}
