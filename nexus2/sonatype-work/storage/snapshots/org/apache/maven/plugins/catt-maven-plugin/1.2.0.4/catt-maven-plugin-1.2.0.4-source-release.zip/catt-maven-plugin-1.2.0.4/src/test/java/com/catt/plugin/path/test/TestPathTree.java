package com.catt.plugin.path.test;

import java.util.List;

import org.junit.Test;

import com.catt.plugin.path.PathTree;

public class TestPathTree {

	/**
	 * 路径前缀提取效果测试
	 */
	@Test
	public void testGetPathPrefixSet() {
		String[] paths = {
			"D:\\mavenRepository\\classworlds\\classworlds\\1.1\\classworlds-1.1.jar",
			"D:\\mavenRepository\\com\\catt\\catt-utils\\1.1.1.0\\catt-utils-1.1.1.0.jar",
			"D:\\mavenRepository\\commons-cli\\commons-cli\\1.0\\commons-cli-1.0.jar",
			"D:\\mavenRepository\\commons-io\\commons-io\\2.4\\commons-io-2.4.jar",
			"D:\\mavenRepository\\org\\codehaus\\plexus\\plexus-utils\\1.5.8\\plexus-utils-1.5.8.jar",
			"D:\\mavenRepository\\org\\codehaus\\plexus\\plexus-container-default\\1.0-alpha-9-stable-1\\plexus-container-default-1.0-alpha-9-stable-1.jar",
			"D:\\mavenRepository\\org\\codehaus\\plexus\\plexus-interactivity-api\\1.0-alpha-4\\plexus-interactivity-api-1.0-alpha-4.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\reporting\\maven-reporting-api\\2.0.6\\maven-reporting-api-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-core\\2.0.6\\maven-core-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\doxia\\doxia-sink-api\\1.0-alpha-7\\doxia-sink-api-1.0-alpha-7.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-project\\2.0.6\\maven-project-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-plugin-descriptor\\2.0.6\\maven-plugin-descriptor-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-profile\\2.0.6\\maven-profile-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-error-diagnostics\\2.0.6\\maven-error-diagnostics-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\wagon\\wagon-provider-api\\1.0-beta-2\\wagon-provider-api-1.0-beta-2.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-monitor\\2.0.6\\maven-monitor-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-artifact\\2.0.6\\maven-artifact-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-plugin-parameter-documenter\\2.0.6\\maven-plugin-parameter-documenter-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-plugin-api\\2.0.6\\maven-plugin-api-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-plugin-registry\\2.0.6\\maven-plugin-registry-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-model\\2.0.6\\maven-model-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-settings\\2.0.6\\maven-settings-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-artifact-manager\\2.0.6\\maven-artifact-manager-2.0.6.jar",
			"D:\\mavenRepository\\org\\apache\\maven\\maven-repository-metadata\\2.0.6\\maven-repository-metadata-2.0.6.jar",
			"D:\\commonLib\\j2se\\catt\\1.1.1.0\\catt-utils.jar",
			"D:\\commonLib\\j2se\\catt\\1.1.1.0\\catt-conf.jar",
			"D:\\commonLib\\j2se\\logback.jar",
		};

		// 构造路径树
		PathTree pt = new PathTree("Test");
		for(String path : paths) {
			pt.add(path);
		}
		System.out.println(pt.toPrintTree());
		
		System.out.println("win mode1:");
		printList(pt.getWinPathPrefixSet(PathTree.PRE_MODE_LEAST));
		
		System.out.println("win mode2:");
		printList(pt.getWinPathPrefixSet(PathTree.PRE_MODE_STAND));
		
		System.out.println("win mode3:");
		printList(pt.getWinPathPrefixSet(PathTree.PRE_MODE_MOST));
		
		
		System.out.println("linux mode1:");
		printList(pt.getLinuxPathPrefixSet(PathTree.PRE_MODE_LEAST));
		
		System.out.println("linux mode2:");
		printList(pt.getLinuxPathPrefixSet(PathTree.PRE_MODE_STAND));
		
		System.out.println("linux mode3:");
		printList(pt.getLinuxPathPrefixSet(PathTree.PRE_MODE_MOST));
	}
	
	private void printList(List<String> list) {
		System.out.println("+++++++++++++++++");
		for(String s : list) {
			System.out.println(s);
		}
		System.out.println("-----------------");
	}
}
