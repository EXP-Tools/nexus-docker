package com.catt.plugin.core;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.catt.plugin.Config;
import com.catt.plugin.core.builder.ScriptDirector;
import com.catt.plugin.core.envm.FinalParams;
import com.catt.plugin.core.envm.ProjectNames;
import com.catt.plugin.core.envm.ScriptNames;
import com.catt.plugin.core.envm.ScriptTypes;
import com.catt.plugin.core.manager.JarLoader;
import com.catt.plugin.core.manager.JarMgr;
import com.catt.plugin.core.manager.LogMgr;
import com.catt.plugin.utils.PathUtils;


/**
 * <PRE>
 * 自动创建脚本插件:核心功能部分
 * </PRE>
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * @version   1.0 2014-9-16
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 */
public class Core {

	/**
	 * 单例
	 */
	private static volatile Core instance;
	
	/**
	 * 私有化构造函数
	 */
	private Core() {}
	
	/**
	 * 获取单例
	 * @return 单例
	 */
	public static Core getInstn() {
		if(instance == null) {
			synchronized (Core.class) {
				if(instance == null) {
					instance = new Core();
				}
			}
		}
		return instance;
	}
	
	/**
	 * 打包项目
	 */
	public void packageProject() {
		LogMgr.info("[自动创建脚本插件-脚本创建] 开始运行.");
		
		// 加载各个项目的依赖包路径
		LogMgr.info("正在检索各项目依赖包...");
		loadJars();
		LogMgr.info("各项目依赖包检索完成:" + JarMgr.getInstn().toPrintJars());
		
		// 拷贝各项目的依赖包,同时修改依赖包路径为拷贝后的路径
		LogMgr.info("正在复制各项目依赖包...");
		copyJars();
		LogMgr.info("各项目依赖包复制完成:" + JarMgr.getInstn().toPrintJars());
		
		// 创建脚本
		LogMgr.info("正在创建各项目脚本...");
		createScript();
		LogMgr.info("各项目脚本创建完成.");
		
		if(JarMgr.getInstn().isLostJar() == true) {
			LogMgr.warn("部分项目存在缺包的情况,对应所创建的脚本可能无法运行.");
		}
		LogMgr.info("[自动创建脚本插件-脚本创建] 运行结束.");
	}
	
	/**
	 * 加载各个项目的依赖包路径。
	 * 所有依赖包都会被归入 JarMgr 管理器管理。
	 */
	private void loadJars() {
		// 主项目：添加自身jar包
		JarMgr.getInstn().add(Config.getInstn().getProjectName(), 
				PathUtils.comPath(
						Config.getInstn().getLibPath(), 
						Config.getInstn().getReleaseName()));
		
		// 主项目：根据cp配置获取依赖包
		JarLoader.getInstn().loadMainPrjCp();
		
		// 其他项目：根据inner_project_jars配置检索依赖包
		JarLoader.getInstn().loadInnerPrjJars();
	}
	
	/**
	 * 复制各个项目的依赖包到主项目的lib目录下
	 */
	private void copyJars() {
		copyJars2Lib(Config.getInstn().getProjectName());
		copyJars2Lib(ProjectNames.ANT);
		copyJars2Lib(ProjectNames.CRYPTO);
		copyJars2Lib(ProjectNames.AUTODB);
		copyJars2Lib(ProjectNames.STARTCHECK);
	}
	
	/**
	 * 复制指定项目的依赖包到主项目的lib目录下。
	 * 其中主项目的依赖包复制到 lib 下，其他项目的依赖包复制到 lib/prjName 目录下。
	 * 
	 * @param prjName 项目名称
	 */
	private void copyJars2Lib(String prjName) {
		List<String> prjJarPaths = JarMgr.getInstn().getJarPaths(prjName);
		List<String> modifyPaths = new LinkedList<String>();
		
		for(String jarPath : prjJarPaths) {
			
			// 根据需要生成的脚本类型,排除不需要复制的jar包
			if(ScriptTypes.LIB.equalsIgnoreCase(
					Config.getInstn().getScriptType()) && 
					jarPath.startsWith(Config.getInstn().getLibPath())) {
				// none
				
			} else if(ScriptTypes.COMMONLIB.equalsIgnoreCase(
						Config.getInstn().getScriptType()) && 
					jarPath.startsWith(Config.getInstn().getCommonLibPath())) {
				// none
				
			} else if(ScriptTypes.MAVEN.equalsIgnoreCase(
						Config.getInstn().getScriptType()) && 
					jarPath.startsWith(Config.getInstn().getMavenLibPath())) {
				// none
				
			// 主项目包不需要复制(因为尚未编译,还不存在)
			} else if(jarPath.endsWith(Config.getInstn().getReleaseName())) {
				// none
				
			// 复制jar包到脚本发布目录下的lib文件夹中
			} else {
				String toDir = PathUtils.comPath(
						Config.getInstn().getReleasePath(), "lib");
				if(!Config.getInstn().getProjectName().equals(prjName)) {
					toDir = PathUtils.comPath(toDir, prjName);
				}
				
				File srcFile = new File(jarPath);
				String jarName = srcFile.getName();
				
				// catt的jar包复制后需移除版本号
				Pattern ptn = Pattern.compile(FinalParams.CATT_JAR_REGEX);
				Matcher mth = ptn.matcher(jarName);
				
				//当带版本号时group(1)会以 - 结尾
				if(mth.find()) {
					jarName = (mth.group(1) + ".jar").replace("-.jar", ".jar");
				}
				jarPath = PathUtils.comPath(toDir, jarName);
				
				try {
					File toFile = new File(jarPath);
					com.catt.util.io.FileUtils.copyFile(srcFile, toFile);
					
				} catch (Exception e) {
					if(false == e.getMessage().matches(
							"^Source.*and destination.*are the same$")) {
						
						if(true == e.getMessage().matches(
								"Source.*\\d{8,8}\\.\\d{6,6}-\\d\\.jar'" +
								" does not exist")) {
							LogMgr.error("无法复制 [" + srcFile.getPath() + 
									"],此为maven自动编译的临时jar包," +
									"请先手动[Install]对应项目到本地仓库.", e);
						} else {
							LogMgr.error("复制 [" + srcFile.getPath() + 
									"] 到 [" + toDir + "] 目录失败.", e);
						}
					}
				} finally {
					
					// 对于非Maven项目,复制到 ./lib 目录
					// 对于Maven项目,复制到 ./target/prjName-prjVersion/lib 目录
					// 由于jar包的 复制路径 就是 最终记录到脚本中的路径,因此Maven项目需修正记录为 ./lib
					if(Config.getInstn().isCallByMaven() == true) {
						jarPath = jarPath.replace(PathUtils.comPath(
									Config.getInstn().getReleasePath(), "lib"), 
								Config.getInstn().getLibPath());
					}
				}
			}
			
			//记录复制后的依赖包路径
			modifyPaths.add(jarPath);
		}
		
		//把路径修改记录覆写到 jarMgr 内存,用于之后创建脚本
		JarMgr.getInstn().cover(prjName, modifyPaths);
	}
	
	/**
	 * 创建各个项目的脚本
	 */
	private void createScript() {
		if(Config.getInstn().isCpsMain()) {
			ScriptDirector.createScripts(
					Config.getInstn().getReleasePath(), 
					ScriptDirector.getMainScript());
		}
		
		if(Config.getInstn().isCpsAnt()) {
			ScriptDirector.createScripts(
					Config.getInstn().getReleasePath(), 
					ScriptDirector.getAntScript());
		}
		
		if(Config.getInstn().isCpsCrypto()) {
			ScriptDirector.createScripts(
					Config.getInstn().getReleasePath(), 
					ScriptDirector.getCryptoScript());
		}
		
		if(Config.getInstn().isCpsAutodb()) {
			ScriptDirector.createScripts(
					Config.getInstn().getReleasePath(), 
					ScriptDirector.getAutodbScript());
		}
		
		if(Config.getInstn().isCpsStartcheck()) {
			ScriptDirector.createScripts(
					Config.getInstn().getReleasePath(), 
					ScriptDirector.getStartcheckScript());
		}
	}
	
	/**
	 * 清理项目
	 */
	public void cleanProject() {
		LogMgr.info("[自动创建脚本插件-脚本清理] 开始运行.");
		
		// Maven项目只需要简单移除发布目录即可
		if(true == Config.getInstn().isCallByMaven()) {
			com.catt.plugin.utils.FileUtils.deleteFolder(
					Config.getInstn().getReleasePath());
			
		// 非Maven项目只需移除脚本和lib目录下各内联项目的jar包
		} else {
			
			//删除脚本
			for(String scriptName : ScriptNames.ALL_SCRIPTS) {
				com.catt.plugin.utils.FileUtils.deleteFile(PathUtils.comPath(
						Config.getInstn().getReleasePath(), scriptName));
			}
			
			//删除jar包
			com.catt.plugin.utils.FileUtils.deleteFolder(PathUtils.comPath(
					Config.getInstn().getLibPath(), ProjectNames.ANT));
			com.catt.plugin.utils.FileUtils.deleteFolder(PathUtils.comPath(
					Config.getInstn().getLibPath(), ProjectNames.AUTODB));
			com.catt.plugin.utils.FileUtils.deleteFolder(PathUtils.comPath(
					Config.getInstn().getLibPath(), ProjectNames.CRYPTO));
			com.catt.plugin.utils.FileUtils.deleteFolder(PathUtils.comPath(
					Config.getInstn().getLibPath(), ProjectNames.STARTCHECK));
		}
		
		LogMgr.info("[自动创建脚本插件-脚本清理] 运行结束.");
	}
}
