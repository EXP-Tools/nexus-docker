package com.catt.plugin.utils.test;

import java.util.List;

import org.junit.Test;

import com.catt.plugin.utils.SearchUtils;

public class TestSearchUtils {

	/**
	 * 版本类检索效果测试
	 */
	@Test
	public void testSearch() {
		List<String> files = SearchUtils.search("Version.java", "src");
		System.out.println(files);
	}
	
	//TODO
}
