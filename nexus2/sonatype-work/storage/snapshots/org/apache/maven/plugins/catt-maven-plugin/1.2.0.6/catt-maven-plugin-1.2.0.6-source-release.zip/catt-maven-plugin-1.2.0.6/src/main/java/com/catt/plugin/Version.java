package com.catt.plugin;

import com.catt.pub.connector.bean.VersionBean;
import com.catt.pub.connector.version.BaseVersion;

/**
 * <PRE>
 * 版本类
 * </PRE>
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * @version   1.0 2014-07-22
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 */
public class Version extends BaseVersion {
	
	static {
		procName = "AutoCreateScript"; 			//项目名称
		projectNote = "自动化创建脚本插件"; 			//项目说明
		teamName = "综合网管-接口组"; 				//小组名称
		cmd = "start.bat/start.sh";
		
		defDataSourceId = ""; 					//默认数据源ID
		supportScriptName = ""; 				//脚本名称
		scriptCharset = "UTF-8";				//脚本内容编码
		
/////////////////////////////////升级记录////////////////////////////////////////
		VersionBean vb = null;
		
		vb = new VersionBean();
		vb.setAuthor("廖权斌");
		vb.setVer("V1.0.0.2-SNAPSHOT");
		vb.setReleaseTime("2014-10-20 18:00:00");
		vb.setLastModifyContent("1、重构。\r\n");
		vb.setScriptVersion(1.0);
		addVersion(vb);
		
		vb = new VersionBean();
		vb.setAuthor("廖权斌");
		vb.setVer("V1.2.0.1");
		vb.setReleaseTime("2015-05-20 18:00:00");
		vb.setLastModifyContent(
				"1、修正unix模板检索项目进程号方法，避免关联到其他引用了该jar包的项目。\r\n");
		vb.setScriptVersion(1.0);
		addVersion(vb);
		
		vb = new VersionBean();
		vb.setAuthor("廖权斌");
		vb.setVer("V1.2.0.2");
		vb.setReleaseTime("2015-08-01 18:00:00");
		vb.setLastModifyContent(
				"1、修正检索路径算法异常。\r\n");
		vb.setScriptVersion(1.0);
		addVersion(vb);
		
		vb = new VersionBean();
		vb.setAuthor("廖权斌");
		vb.setVer("V1.2.0.3");
		vb.setReleaseTime("2015-09-17 18:00:00");
		vb.setLastModifyContent(
				"1、增加可选开关：主项目jar包是否带版本号。\r\n");
		vb.setScriptVersion(1.0);
		addVersion(vb);
		
		vb = new VersionBean();
		vb.setAuthor("廖权斌");
		vb.setVer("V1.2.0.4");
		vb.setReleaseTime("2015-10-13 18:00:00");
		vb.setLastModifyContent(
				"1、调整代码逻辑，使得Maven快照版本可用于项目打包。\r\n");
		vb.setScriptVersion(1.0);
		addVersion(vb);
		
		vb = new VersionBean();
		vb.setAuthor("廖权斌");
		vb.setVer("V1.2.0.5");
		vb.setReleaseTime("2015-11-28 18:00:00");
		vb.setLastModifyContent(
				"1、 把主项目包放在CP最前面，以便于其可以覆写支撑包的类。\r\n" + 
				"2、 增加线程后缀配置，避免单独配置时总是人工修改线程名。\r\n" + 
				"3、增加线程名修改脚本。\r\n"
		);
		vb.setScriptVersion(1.0);
		addVersion(vb);
		
		vb = new VersionBean();
		vb.setAuthor("廖权斌");
		vb.setVer("V1.2.0.6");
		vb.setReleaseTime("2016-01-15 18:00:00");
		vb.setLastModifyContent(
				"1、线程名修改脚本更名为 modify_thName.bat/sh。\r\n" + 
				"2、修正内联项目linux脚本无法在控制台交互异常。\r\n"
		);
		vb.setScriptVersion(1.0);
		addVersion(vb);
	}
	
	/**
	 * main方法，调用父类show方法输出
	 * 
	 * @param args 参数,-v:打印显示信息；-u更新文件，找不到则新建；-c创建，有旧文件则先备份
	 */
	public static void main(String[] args) {
		
		if(args == null || args.length <= 0) {
			args = new String[]{"-v"};
		}
		new Version().show(args);
	}
}
