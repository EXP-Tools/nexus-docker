package com.catt.plugin.core.builder.impl;

import java.util.List;

import com.catt.plugin.Config;
import com.catt.plugin.core.builder.IBuilder;
import com.catt.plugin.core.builder.ProjectScript;
import com.catt.plugin.core.envm.FinalParams;
import com.catt.plugin.core.envm.ProjectNames;
import com.catt.plugin.core.envm.ScriptNames;
import com.catt.plugin.core.manager.JarMgr;
import com.catt.plugin.path.PathTree;
import com.catt.plugin.template.Template;
import com.catt.plugin.template.envm.Placeholders;
import com.catt.plugin.template.envm.TemplateFiles;
import com.catt.plugin.utils.PathUtils;
import com.catt.plugin.utils.StandUtils;

/**
 * <PRE>
 * Ant项目脚本构建器
 * </PRE>
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * @version   1.0 2014-9-19
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 */
final public class AntBuilder implements IBuilder {

	/**
	 * Ant项目脚本容器
	 */
	private ProjectScript ps;
	
	/**
	 * 构造函数
	 */
	public AntBuilder() {
		this.ps = new ProjectScript(ProjectNames.ANT);
	}
	
	@Override
	public ProjectScript constructScripts() {
		return ps;
	}

	@Override
	public void buildDosStart() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildUnixStart() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildUnixStop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildDosVersion() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildUnixVersion() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildDosMonitor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildUnixMonitor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildAntStart() {
		//读取模板
		Template tpl = new Template(ScriptNames.BUILD_BAT);
		tpl.read(TemplateFiles.BUILD_TEMPLATE_DOS);
		
		//生成脚本内容，并标准化
		String scriptContent = StandUtils.unix2dos(tpl.getContent());
		
		//把脚本内容植入到项目脚本容器
		ps.addScript(ScriptNames.BUILD_BAT, scriptContent);
	}

	@Override
	public void buildAntConf() {
		StringBuilder sb = new StringBuilder();
		
		//获取主项目的依赖包集合
		List<String> jarPaths = JarMgr.getInstn().getWinJarPaths(
				Config.getInstn().getProjectName());
		
		//构造路径树,获取路径前缀集合
		PathTree pt = new PathTree("DOS-" + Config.getInstn().getProjectName());
		pt.addMore(jarPaths);
		List<String> pathPres = pt.getWinPathPrefixSet(
				Config.getInstn().getPathPrefixMode());
		int preNum = pathPres.size();
				
				/////////////////////////////////////////////////////
		// 加载模板
		Template tpl = new Template(ScriptNames.BUILD_XML);
		tpl.read(TemplateFiles.BUILD_TEMPLATE_XML);
		
		/////////////////////////////////////////////////////
		// 设置主项目名称
		tpl.set(Placeholders.PROJECT_NAME, Config.getInstn().getProjectName());
		
		// 设置主项目版本
		if(Config.getInstn().isMainProVersion() == true) {
			tpl.set(Placeholders.PROJECT_VERSION, 
					"-" + Config.getInstn().getProjectVersion());
		} else {
			tpl.set(Placeholders.PROJECT_VERSION, "");
		}
				
		// 设置源码目录
		if(Config.getInstn().isCallByMaven() == true) {
			tpl.set(Placeholders.SRC_DIR, "src/main");
		} else {
			tpl.set(Placeholders.SRC_DIR, "src");
		}
		
		// 设置属性变量
		sb.setLength(0);
		for(int i = 0; i < preNum; i++) {
			sb.append("    <property name=\"lib").append(i);
			sb.append(".dir\" location=\"").append(pathPres.get(i));
			sb.append("\"/>\r\n");
		}
		tpl.set(Placeholders.VARIABLE_DECLARATION, sb.toString());
		
		// 设置CP
		sb.setLength(0);
		for(String jarPath : jarPaths) {
			boolean isFind = false;
			sb.append("        <fileset dir=\"");
			
			for(int i = 0; i < preNum; i++) {
				String pathPre = pathPres.get(i) + "\\";
				
				if(jarPath.startsWith(pathPre)) {
					isFind = true;
					sb.append("${lib").append(i);
					sb.append(".dir}\" includes=\"");
					sb.append(jarPath.replace(pathPre, ""));
					break;
				}
			}
			
			if(isFind == false) {
				int idx = jarPath.indexOf('\\');	//前面取的一定是win格式路径
				sb.append(jarPath.substring(0, idx));
				sb.append("\" includes=\"");
				sb.append(jarPath.substring(idx + 1));
			}
			sb.append("\" />\r\n");
		}
		tpl.set(Placeholders.CLASSPATH, sb.toString());
		
		// 设置JDK版本
		tpl.set(Placeholders.JDK_VERSION, FinalParams.JDK_VERSION);
		
		// 设置项目编码
		tpl.set(Placeholders.PROJECT_CHARSET, Config.getInstn().getCharset());
		
		// 设置收尾工作:移除内联项目的jar包
		sb.setLength(0);
		sb.append("        <delete dir=\"").append(PathUtils.combPath(
				Config.getInstn().getWinLibPath(), ProjectNames.MTN));
		sb.append("\"/>\r\n");
		sb.append("        <delete dir=\"").append(PathUtils.combPath(
				Config.getInstn().getWinLibPath(), ProjectNames.CRYPTO));
		sb.append("\"/>\r\n");
		sb.append("        <delete dir=\"").append(PathUtils.combPath(
				Config.getInstn().getWinLibPath(), ProjectNames.AUTODB));
		sb.append("\"/>\r\n");
		sb.append("        <delete dir=\"").append(PathUtils.combPath(
				Config.getInstn().getWinLibPath(), ProjectNames.STARTCHECK));
		sb.append("\"/>\r\n");
		tpl.set(Placeholders.END_OP, sb.toString());
		
		/////////////////////////////////////////////////////
		//将脚本内容其植入到项目脚本容器,等待构造
		ps.addScript(ScriptNames.BUILD_XML, tpl.getContent());
	}

}
