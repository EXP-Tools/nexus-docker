package com.catt.plugin;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.maven.artifact.Artifact;
import org.apache.maven.artifact.handler.ArtifactHandler;
import org.apache.maven.model.Dependency;
import org.apache.maven.model.Profile;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.project.MavenProject;

import com.catt.util.regex.ValidateUtils;

/**
 * <PRE>
 * 凯通J2SE项目打包插件
 * 说明：根据脚本类型，自动生成J2SE项目的启动、停止、启动检查等脚本
 * 
 * 		该插件在package生命周期后运行execute phase
 * 		运行插件前需要进行jar依赖分析requiresDependencyResolution
 * 
 * </PRE>
 * 
 * <B>项 目：</B>凯通J2SE开发平台(KTJSDP) <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * 
 * @version 1.0 2014-3-14
 * @author 廖权斌：liaoquanbin@gdcattsoft.com
 * @since jdk版本：jdk1.6
 * 
 * @goal package
 * @requiresDependencyResolution runtime
 * @execute phase= "package"
 * 
 */
public class PackageMojo extends AbstractMojo {

	/**
	 * The project to create a build for.
	 * 
	 * @parameter default-value="${project}"
	 * @required
	 * @readonly
	 */
	private MavenProject project;

	/**
	 * The local repository where the artifacts are located.
	 * 
	 * @parameter default-value="${localRepository}"
	 * @required
	 * @readonly
	 */
//	private ArtifactRepository localRepository;

	/**
	 * The remote repositories where artifacts are located.
	 * 
	 * @parameter default-value="${project.remoteArtifactRepositories}"
	 * @readonly
	 */
//	private List remoteRepositories;

	/**
	 * 路径生成需要
	 */
	private Properties executionProperties;

	/**
	 * <PRE>
	 * 脚本类型，默认脚本引用maven仓库jar的相对路径；
	 * 类型：maven|lib|commonLib
	 * </PRE>
	 * 
	 * @parameter default-value="maven"
	 * @required
	 */
	private String scriptType;
	
	/**
	 * linux默认lib目录路径
	 * 
	 * @parameter default-value="./lib"
	 * @required
	 */
	private String linuxLibPath;
	
	/**
	 * win默认lib目录路径
	 * 
	 * @parameter default-value=".\\lib"
	 * @required
	 */
	private String winLibPath;
	
	
	/**
	 * win默认commonLib目录路径
	 * 
	 * @parameter default-value="D:\\commonLib"
	 * @required
	 */
	private String winCommonLibPath;
	
	/**
	 * linux默认commonLib目录路径
	 * 
	 * @parameter default-value="/home/cattsoft/commonLib"
	 * @required
	 */
	private String linuxCommonLibPath;
	
	
	/**
	 * win默认maven仓库路径
	 * 
	 * @parameter default-value="${settings.localRepository}"
	 * @required
	 */
	private String winMavenLibPath;
	
	/**
	 * linux默认maven仓库路径
	 * 
	 * @parameter default-value="/home/cattsoft/mavenRepository"
	 * @required
	 */
	private String linuxMavenLibPath;
	
	
	/**
	 * 项目启动类路径
	 * 
	 * @parameter default-value="com.catt.demo.Main"
	 * @required
	 */
	private String mainClass;
	
	/**
	 * 项目版本类路径
	 * 
	 * @parameter default-value="com.catt.demo.Version"
	 * @required
	 */
	private String versionClass;
	
	/**
	 * 项目编码
	 * 
	 * @parameter default-value="UTF-8"
	 * @required
	 */
	private String charset;
	

	/** {@inheritDoc} */
	public void execute() throws MojoExecutionException {
		String projectName = project.getArtifactId();
		String version = project.getVersion();
		String releasePath = getProjectReleasePath(project);
		
		getLog().info("[自动生成脚本]插件执行开始.");
		
		StringBuffer tmpLog = new StringBuffer();
		tmpLog.append("本次生成脚本的依赖参数如下: {");
		tmpLog.append("\r\n\t projectName = ").append(projectName);
		tmpLog.append("\r\n\t version = ").append(version);
		tmpLog.append("\r\n\t releasePath = ").append(releasePath);
		tmpLog.append("\r\n\t scriptType = ").append(scriptType);
		tmpLog.append("\r\n\t mainClass = ").append(mainClass);
		tmpLog.append("\r\n\t versionClass = ").append(versionClass);
		tmpLog.append("\r\n\t charset = ").append(charset);
		tmpLog.append("\r\n\t linuxLibPath = ").append(linuxLibPath);
		tmpLog.append("\r\n\t winLibPath = ").append(winLibPath);
		tmpLog.append("\r\n\t linuxCommonLibPath = ").append(linuxCommonLibPath);
		tmpLog.append("\r\n\t winCommonLibPath = ").append(winCommonLibPath);
		tmpLog.append("\r\n\t linuxMavenLibPath = ").append(linuxMavenLibPath);
		tmpLog.append("\r\n\t winMavenLibPath = ").append(winMavenLibPath);
		tmpLog.append("\r\n}");
		getLog().info(tmpLog.toString());

		//////////////////////////////////////////////////////////
		// 准备工作1：获取引用包路径
		//////////////////////////////////////////////////////////
		getLog().info("生成项目 [" + projectName + "] 脚本前准备...");
		
		/*
		 * 获取项目所引用的全部包路径
		 * 分别记录成两个版本：winPaths 和 linuxPaths
		 */
		List<String> winPaths = new ArrayList<String>();
		List<String> linuxPaths = new ArrayList<String>();
		getProjectAllJarPaths(project, winPaths, linuxPaths);
		getLog().info("获取项目 [" + projectName + "] 的所有引用包完成.");
		printfPathList(projectName, winPaths, linuxPaths);
		
		/*
		 * 获取 startCheck 工具所引用的全部包路径
		 * 分别记录成两个版本：winScJarPaths 和 linuxScJarPaths
		 * 
		 * 与scriptType无关，因为实际的maven项目pom.xml一般都不会引用startCheck的相关jar包，
		 * 因此直接从commonLib找依赖包，找不全则把依赖全设置为./lib目录下
		 */
		List<String> winScJarPaths = new ArrayList<String>();
		List<String> linuxScJarPaths = new ArrayList<String>();
		getStartCheckAllJarPaths(winScJarPaths, linuxScJarPaths);
		getLog().info("获取工具插件 [startCheck] 的所有引用包完成.");
		printfPathList("startCheck", winScJarPaths, linuxScJarPaths);
				
		/*
		 * 获取 autoDB 工具所引用的全部包路径
		 * 分别记录成两个版本：winAdJarPaths 和 linuxAdJarPaths
		 * 
		 * 与scriptType无关，因为实际的maven项目pom.xml一般都不会引用autoDB的相关jar包，
		 * 因此直接从commonLib找依赖包，找不全则把依赖全设置为./lib目录下
		 */
		List<String> winAdJarPaths = new ArrayList<String>();
		List<String> linuxAdJarPaths = new ArrayList<String>();
		getAutoDbAllJarPaths(winAdJarPaths, linuxAdJarPaths);
		getLog().info("获取工具插件 [autoDB] 的所有引用包完成.");
		printfPathList("autoDB", winAdJarPaths, linuxAdJarPaths);
		
		//////////////////////////////////////////////////////////
		// 准备工作2：转换引用包路径（替换路径前缀）
		//////////////////////////////////////////////////////////
		final String[] winPrefixPaths = {
				winLibPath.replace('/', '\\'),
				winCommonLibPath.replaceFirst("d:", "D:").replace('/', '\\'),
				winMavenLibPath.replaceFirst("d:", "D:").replace('/', '\\')
		};
		
		final String[] linuxPrefixPaths = {
				linuxLibPath.replace('\\', '/'),
				linuxCommonLibPath.replace('\\', '/'),
				linuxMavenLibPath.replace('\\', '/')
		};
		
		// 替换项目引用包的路径前缀
		replaceWinPathPrefix(winPrefixPaths, winPaths);
		replaceLinuxPathPrefix(linuxPrefixPaths, linuxPaths);
		getLog().info("替换项目 [" + projectName + "] 所有引用包的路径前缀完成.");
		
		// 替换工具插件 [startCheck] 引用包的路径前缀
		replaceWinPathPrefix(winPrefixPaths, winScJarPaths);
		replaceLinuxPathPrefix(linuxPrefixPaths, linuxScJarPaths);
		getLog().info("替换工具插件 [startCheck] 所有引用包的路径前缀完成.");
		
		// 替换工具插件 [autoDB] 引用包引用包的路径前缀
		replaceWinPathPrefix(winPrefixPaths, winAdJarPaths);
		replaceLinuxPathPrefix(linuxPrefixPaths, linuxAdJarPaths);
		getLog().info("替换工具插件 [autoDB] 所有引用包的路径前缀完成.");
		
		//////////////////////////////////////////////////////////
		// 开始创建脚本
		//////////////////////////////////////////////////////////
		getLog().info("开始生成脚本...");
		
		if(0 == CreateScriptUtils.createWinStartScript(releasePath, 
				projectName, winPrefixPaths, winPaths, 
				mainClass, charset)) {
			getLog().info("创建脚本[start.bat]成功.");
		}
		
		if(0 == CreateScriptUtils.createLinuxStartScript(releasePath, 
				projectName, linuxPrefixPaths, linuxPaths, 
				mainClass, charset)) {
			getLog().info("创建脚本[start.sh]成功.");
		}
		
		if(0 == CreateScriptUtils.createWinStartMonitorScript(releasePath, 
				projectName, winPrefixPaths, winPaths, 
				mainClass, charset)) {
			getLog().info("创建脚本[start_monitor.bat]成功.");
		}
		
		if(0 == CreateScriptUtils.createLinuxStartMonitorScript(releasePath, 
				projectName, linuxPrefixPaths, linuxPaths, 
				mainClass, charset)) {
			getLog().info("创建脚本[start_monitor.sh]成功.");
		}
		
		if(0 == CreateScriptUtils.createLinuxStopScript(releasePath, 
				projectName, charset)) {
			getLog().info("创建脚本[stop.sh]成功.");
		}
		
		if(0 == CreateScriptUtils.createWinCryptoScript(releasePath, 
				winPrefixPaths, winPaths, charset, scriptType)) {
			getLog().info("创建脚本[crypto.bat]成功.");
		}
		
		if(0 == CreateScriptUtils.createLinuxCryptoScript(releasePath, 
				linuxPrefixPaths, linuxPaths, charset, scriptType)) {
			getLog().info("创建脚本[crypto.sh]成功.");
		}
		
		if(0 == CreateScriptUtils.createWinVersionScript(releasePath, 
				projectName, version, winPrefixPaths, winPaths, 
				versionClass, charset, scriptType)) {
			getLog().info("创建脚本[version.bat]成功.");
		}
		
		if(0 == CreateScriptUtils.createLinuxVersionScript(releasePath, 
				projectName, version, linuxPrefixPaths, linuxPaths,   
				versionClass, charset, scriptType)) {
			getLog().info("创建脚本[version.sh]成功.");
		}
		
		if(0 == CreateScriptUtils.createWinStartCheckScript(releasePath, 
				winPrefixPaths, winScJarPaths, charset)) {
			getLog().info("创建脚本[startCheck.bat]成功.");
		}
		
		if(0 == CreateScriptUtils.createLinuxStartCheckScript(releasePath, 
				linuxPrefixPaths, linuxScJarPaths, charset)) {
			getLog().info("创建脚本[startCheck.sh]成功.");
		}
		
		if(0 == CreateScriptUtils.createWinAutoDBScript(releasePath, 
				winPrefixPaths, winAdJarPaths, charset)) {
			getLog().info("创建脚本[autoDB.bat]成功.");
		}
		
		if(0 == CreateScriptUtils.createLinuxAutoDBScript(releasePath, 
				linuxPrefixPaths, linuxAdJarPaths, charset)) {
			getLog().info("创建脚本[autoDB.sh]成功.");
		}
		
		getLog().info("[自动生成脚本]插件执行完成.");
	}

	/**
	 * 获取项目自身所引用的所有jar包路径
	 * @param project
	 * @param winPaths_out
	 * @param linuxPaths_out
	 * @throws MojoExecutionException
	 */
	private void getProjectAllJarPaths(MavenProject project, 
			List<String> winPaths_out, List<String> linuxPaths_out) 
			throws MojoExecutionException {
		
		List<String> paths = null;
		String projectName = project.getArtifactId();
		String version = project.getVersion();
		
		//项目依赖的pom坐标
		@SuppressWarnings("unchecked")
		List<Artifact> artifacts = project.getCompileArtifacts();
		
		// jar文件都放在根目录下的lib目录
		if ("lib".equalsIgnoreCase(scriptType)) {
			paths = getJarPathTypeOfLib(artifacts);
			winPaths_out.addAll(changeToWinPaths(paths));
			linuxPaths_out.addAll(changeToLinuxPaths(paths));
			
		// jar文件都引用D:\commonLib目录 或 /home/cattsoft/commonLib目录
		} else if ("commonLib".equalsIgnoreCase(scriptType)) {
			paths = getJarPathTypeOfCommonLib(artifacts);
			winPaths_out.addAll(changeToWinPaths(paths));
			linuxPaths_out.addAll(changeToLinuxPaths(paths));
			
		// jar文件都引用maven仓库相对路径
		} else {
			paths = getJarPathTypeOfMaven(artifacts);
			winPaths_out.addAll(changeToWinPaths(paths));
			linuxPaths_out.addAll(changeToLinuxPaths(paths));
			
			int size = paths.size();
			for(int i = 0; i < size; i++) {
				String path = winPaths_out.get(i);
				winPaths_out.set(i, winMavenLibPath + "\\" + path);
			}
			for(int i = 0; i < size; i++) {
				String path = linuxPaths_out.get(i);
				linuxPaths_out.set(i, linuxMavenLibPath + "/" + path);
			}
		}
		
		// 项目自身引用的jar包
		winPaths_out.add(0, winLibPath + "\\" + 
				projectName + "-" + version + ".jar");
		linuxPaths_out.add(0, linuxLibPath + "/" + 
				projectName + "-" + version + ".jar");
	}
	
	/**
	 * 获取工具插件startCheck所引用的所有jar包路径
	 * @param winScJarPaths_out
	 * @param linuxScJarPaths_out
	 * @throws MojoExecutionException
	 */
	private void getStartCheckAllJarPaths(
			List<String> winScJarPaths_out, List<String> linuxScJarPaths_out) 
					throws MojoExecutionException {
		
		List<String> startCheckJarPaths = null;
		String[] needJarS = new String[] {
				"catt-pub-start-check.jar",
				"catt-pub-conf.jar", 
				"catt-pub-db.jar", 
				"catt-pub-net.jar", 
				"catt-utils.jar", 
				"dom4j-1.6.1.jar", 
				"commons-net-3.1.jar",  
				"sigar-1.6.4.jar", 
				"jconn3-1.0.jar", 
				"jconn4-1.0.jar",  
				"mysql-5.1.29.jar", 
				"ojdbc-14-1.0.jar", 
				"proxool-0.9.0RC3.jar", 
				"proxool-cglib-0.9.0.jar", 
				"slf4j-api-1.7.5.jar", 
				"logback-catt-1.0.13.jar", 
				"commons-codec-1.7.jar", 
				"commons-httpclient-3.1.jar"
		};
		
		try {
			startCheckJarPaths = getJarPathTypeOfCommonLib(needJarS);
			
		} catch (MojoExecutionException e) {
			getLog().warn("commonLib目录下缺少 StartCheck 模块所需的依赖包，" +
					"使用./lib目录前缀生成该模块的启动脚本.\r\n" + e.getMessage());
			
			startCheckJarPaths = new ArrayList<String>();
			for(String jar : needJarS) {
				startCheckJarPaths.add("./lib/" + jar);
			}
		}
		
		if(ValidateUtils.isWin()) {
			winScJarPaths_out.addAll(startCheckJarPaths);
			linuxScJarPaths_out.addAll(changeToLinuxPaths(winScJarPaths_out));
		} else {
			linuxScJarPaths_out.addAll(startCheckJarPaths);
			winScJarPaths_out.addAll(changeToWinPaths(linuxScJarPaths_out));
		}
	}
	
	/**
	 * 获取工具插件autoDB所引用的所有jar包路径
	 * @param winScJarPaths_out
	 * @param linuxScJarPaths_out
	 * @throws MojoExecutionException
	 */
	private void getAutoDbAllJarPaths(
			List<String> winAdJarPaths_out, List<String> linuxAdJarPaths_out) 
					throws MojoExecutionException {
		
		List<String> autoDbJarPaths = null;
		String[] needJarS = new String[] {
				"catt-pub-update-script.jar",
				"catt-utils.jar",
				"catt-pub-db.jar",
				"catt-pub-conf.jar",
				"dom4j-1.6.1.jar",
				"jconn3-1.0.jar", 
				"jconn4-1.0.jar", 
				"mysql-5.1.29.jar", 
				"ojdbc-14-1.0.jar", 
				"proxool-0.9.0RC3.jar", 
				"proxool-cglib-0.9.0.jar", 
				"slf4j-api-1.7.5.jar",
				"logback-catt-1.0.13.jar",
				"commons-logging-1.1.1.jar"
		};
		
		try {
			autoDbJarPaths = getJarPathTypeOfCommonLib(needJarS);
			
		} catch (MojoExecutionException e) {
			getLog().warn("commonLib目录下缺少 AutoDB 模块所需的依赖包，" +
					"使用./lib目录前缀生成该模块的启动脚本.\r\n" + e.getMessage());
			
			autoDbJarPaths = new ArrayList<String>();
			for(String jar : needJarS) {
				autoDbJarPaths.add("./lib/" + jar);
			}
		}
		
		if(ValidateUtils.isWin()) {
			winAdJarPaths_out.addAll(autoDbJarPaths);
			linuxAdJarPaths_out.addAll(changeToLinuxPaths(winAdJarPaths_out));
		} else {
			linuxAdJarPaths_out.addAll(autoDbJarPaths);
			winAdJarPaths_out.addAll(changeToWinPaths(linuxAdJarPaths_out));
		}
	}
	
	/**
	 * 获取Maven项目的release位置的绝对路径
	 * @param project Maven项目
	 * @return release位置的绝对路径
	 */
	private String getProjectReleasePath(MavenProject project) {
		//TODO 需要可配置
		return project.getBasedir().getAbsolutePath() + 
				File.separator + "target" + File.separator + 
				project.getArtifactId() + "-" + project.getVersion();
	}
	
	/**
	 * 替换windows路径的前缀
	 * @param winPrefixPaths
	 * @param winPaths
	 */
	private void replaceWinPathPrefix(
			String[] winPrefixPaths, List<String> winPaths) {
		
		int pathSize = winPaths.size();
		for(int i = 0; i < pathSize; i++) {
			String path = winPaths.get(i);
			
			for(int j = 0; j < winPrefixPaths.length; j++) {
				if(path.startsWith(winPrefixPaths[j])) {
					path = "%lib" + j + "%" + 
							path.substring(winPrefixPaths[j].length());
					winPaths.set(i, path);
					break;
				}
			}
		}
	}
	
	/**
	 * 替换linux路径的前缀
	 * @param linuxPrefixPaths
	 * @param linuxPaths
	 */
	private void replaceLinuxPathPrefix(
			String[] linuxPrefixPaths, List<String> linuxPaths) {
		
		int pathSize = linuxPaths.size();
		for(int i = 0; i < pathSize; i++) {
			String path = linuxPaths.get(i);
			
			for(int j = 0; j < linuxPrefixPaths.length; j++) {
				if(path.startsWith(linuxPrefixPaths[j])) {
					path = "$lib" + j + 
							path.substring(linuxPrefixPaths[j].length());
					linuxPaths.set(i, path);
					break;
				}
			}
		}
	}
	
	/**
	 * 替换linux路径为win路径
	 *
	 * @param linuxPaths linux路径集合
	 * @return list String
	 */
	public List<String> replaceFileSeparatorToWin(List<String> linuxPaths) {
		List<String> list = new ArrayList<String>();
		for (String path : linuxPaths) {
			path = path.replace("/", "\\");
			list.add(path);
		}
		return list;
	}
	
	/**
	 * 把linux路径转换为win路径
	 * @param linuxPaths linux路径
	 * @return win路径
	 */
	private List<String> changeToWinPaths(List<String> linuxPaths) {
		List<String> winPaths = new ArrayList<String>();
		String path = null;
		
		for(String linuxPath : linuxPaths) {
			path = linuxPath.replace('\\', '/');
			path = path.replaceFirst("(?i)/home/cattsoft", "D:");
			winPaths.add(path.replace('/', '\\'));
		}
		return winPaths;
	}
	
	/**
	 * 把win路径转换为linux路径
	 * @param winPaths win路径
	 * @return linux路径
	 */
	private List<String> changeToLinuxPaths(List<String> winPaths) {
		List<String> linuxPaths = new ArrayList<String>();
		String path = null;
		
		for(String winPath : winPaths) {
			path = winPath.replace('/', '\\');
			path = path.replaceFirst("(?i)D:", "/home/cattsoft");
			linuxPaths.add(path.replace('\\', '/'));
		}
		return linuxPaths;
	}

	/**
	 * 在commlib目录中搜索maven在pom中引入的jar包
	 *
	 * @param artifacts List<Artifact> maven在pom中引入的jar包
	 * @return jar包绝对路径
	 * @throws MojoExecutionException
	 */
	private List<String> getJarPathTypeOfCommonLib(List<Artifact> artifacts) 
			throws MojoExecutionException {
		
		boolean isFindAllJars = true;
		List<String> list = new ArrayList<String>();
		String jarName = null;
		String path = null;
		String folder = linuxCommonLibPath + File.separator + "j2se";
		boolean isWin = ValidateUtils.isWin();
		if (isWin) {
			folder = winCommonLibPath + File.separator + "j2se";
		}
		
		for (Artifact artifact : artifacts) {
			if(artifact.getArtifactId().matches("(?i)catt-.*")) {
				jarName = getJarName(artifact);	//J2SE平台的包不带版本号
			} else {
				jarName = getJarFullName(artifact);
			}
			path = FileNameSearch.searchByFullMatch(jarName, folder);
			
			if (path == null) {
				getLog().warn(folder + " 目录下找不到 " + jarName);
				isFindAllJars = false;
			} else {
				list.add(path);
			}
		}
		if(isFindAllJars == false) {
			throw new MojoExecutionException("项目所需的jar包不完整." +
					"[自动生成脚本]插件运行终止.");
		}
		return list;
	}

	/**
	 * 在commlib目录中搜索已知文件名的jar包
	 * 
	 * @param jarNames 已知文件名的jar包
	 * @return jar包绝对路径
	 * @throws MojoExecutionException 
	 */
	private List<String> getJarPathTypeOfCommonLib(String[] jarNames) 
			throws MojoExecutionException {
		
		boolean isFindAllJars = true;
		List<String> list = new ArrayList<String>();
		String path = null;
		String folder = linuxCommonLibPath + File.separator + "j2se";
		boolean isWin = ValidateUtils.isWin();
		if (isWin) {
			folder = winCommonLibPath + File.separator + "j2se";
		}
		
		for (String jarName : jarNames) {
			path = FileNameSearch.searchByRegexMatch(jarName, folder);
			if (path == null) {
				getLog().warn(folder + " 目录下找不到 " + jarName);
				isFindAllJars = false;
			} else {
				list.add(path);
			}
		}
		if(isFindAllJars == false) {
			throw new MojoExecutionException("项目所需的jar包不完整." +
					"所产生的脚本可能无法正常运行,请手动修正,或补全jar包后重新运行本插件.");
		}
		return list;
	}
	
	/**
	 * 获取相对于./lib目录的所有jar路径
	 *
	 * @param artifacts List<Artifact>
	 * @return jar路径
	 */
	private List<String> getJarPathTypeOfLib(List<Artifact> artifacts) {
		List<String> list = new ArrayList<String>();
		String jarName = null;
		
		for (Artifact artifact : artifacts) {
			jarName = getJarFullName(artifact);
			list.add("./lib/" + jarName);
		}
		return list;
	}

	/**
	 * 获取maven管理的jar包的完整名称
	 *
	 * @param artifact Artifact
	 * @return jar名称
	 */
	private String getJarFullName(Artifact artifact) {
		ArtifactHandler artifactHandler = artifact.getArtifactHandler();
		StringBuffer path = new StringBuffer();

		//报名和版本号
		path.append(artifact.getArtifactId()).append('-')
				.append(artifact.getVersion());

		//标识快照版或发布版
		if (artifact.hasClassifier()) {
			path.append('-').append(artifact.getClassifier());
		}
		
		//后缀
		if (artifactHandler.getExtension() != null
				&& artifactHandler.getExtension().length() > 0) {
			path.append('.').append(artifactHandler.getExtension());
		}
		return path.toString();
	}
	
	/**
	 * 获取maven管理的jar名称（不带版本号、快照版、发布版标识）
	 *
	 * @param artifact Artifact
	 * @return jar名称
	 */
	private String getJarName(Artifact artifact) {
		ArtifactHandler artifactHandler = artifact.getArtifactHandler();
		StringBuffer path = new StringBuffer();

		//包名
		path.append(artifact.getArtifactId());
		
		//后缀
		if (artifactHandler.getExtension() != null
				&& artifactHandler.getExtension().length() > 0) {
			path.append('.').append(artifactHandler.getExtension());
		}
		return path.toString();
	}

	/**
	 * 获取项目依赖jar包的maven仓库相对路径集合
	 *
	 * @return list：String
	 */
	public List<String> getJarPathTypeOfMaven(List<Artifact> artifacts) {
		List<String> list = new ArrayList<String>();

		for (Iterator<Artifact> i = artifacts.iterator(); i.hasNext();) {
			Artifact artifact = i.next();

			String path = null;
			if (Artifact.SCOPE_SYSTEM.equals(artifact.getScope())) {
				path = getUninterpolatedSystemPath(artifact);
				
			} else {
				String groupId = artifact.getGroupId();
				String artifactId = artifact.getArtifactId();
				String version = artifact.getVersion();
				
				String pathPrefix = groupId.replace('.', '/') + "/" + 
						artifactId + "/" + version;
				String jarName = getJarFullName(artifact);
				path = pathPrefix + "/" + jarName;
			}
			list.add(path);
			getLog().debug(artifact.getArtifactId() + ": " + path);
		}
		return list;
	}
	
	/**
	 * 获取范围是system的jar路径
	 * maven-ant-plugin的方法
	 *
	 * @param artifact Artifact
	 * @return String
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String getUninterpolatedSystemPath(Artifact artifact) {
		String managementKey = artifact.getDependencyConflictId();

		for (Iterator<Dependency> it = project.getOriginalModel().getDependencies()
				.iterator(); it.hasNext();) {
			Dependency dependency = it.next();
			if (managementKey.equals(dependency.getManagementKey())) {
				return dependency.getSystemPath();
			}
		}

		for (Iterator<Profile> itp = 
				project.getOriginalModel().getProfiles().iterator(); 
				itp.hasNext();) {
			
			Profile profile = itp.next();
			for (Iterator<Dependency> it = profile.getDependencies().iterator(); it
					.hasNext();) {
				Dependency dependency = it.next();
				if (managementKey.equals(dependency.getManagementKey())) {
					return dependency.getSystemPath();
				}
			}
		}

		String path = artifact.getFile().getAbsolutePath();

		Properties props = new Properties();
		props.putAll(project.getProperties());
		props.putAll(executionProperties);
		props.remove("user.dir");
		props.put("basedir", project.getBasedir().getAbsolutePath());

		SortedMap candidateProperties = new TreeMap();
		for (Iterator it = props.keySet().iterator(); it.hasNext();) {
			String key = (String) it.next();
			String value = new File(props.getProperty(key)).getPath();
			if (path.startsWith(value) && value.length() > 0) {
				candidateProperties.put(value, key);
			}
		}
		if (!candidateProperties.isEmpty()) {
			String value = candidateProperties.lastKey().toString();
			String key = candidateProperties.get(value).toString();
			path = path.substring(value.length());
			path = path.replace('\\', '/');
			return "${" + key + "}" + path;
		}
		return path;
	}
	
	
	/**
	 * 打印 projectName 路径列表
	 * @param projectName
	 * @param winPaths
	 * @param linuxPaths
	 */
	private void printfPathList(String projectName, 
			List<String> winPaths, List<String> linuxPaths) {
		StringBuffer tmpLog = new StringBuffer();
		tmpLog.append(" [" + projectName + "] 的所有引用包清单如下: {");
		tmpLog.append("\r\n\tWindows Jar路径列表: {");
		for(String path : winPaths) {
			tmpLog.append("\r\n\t\t").append(path);
		}
		tmpLog.append("\r\n\t}");
		tmpLog.append("\r\n\tLinux Jar路径列表: {");
		for(String path : linuxPaths) {
			tmpLog.append("\r\n\t\t").append(path);
		}
		tmpLog.append("\r\n\t}");
		tmpLog.append("\r\n}");
		getLog().info(tmpLog.toString());
	}
}
