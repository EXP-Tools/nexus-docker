package com.catt.plugin;


import com.catt.plugin.core.Core;
import com.catt.plugin.core.manager.LogMgr;

/**
 * <PRE>
 * 自动创建脚本插件:Maven调用入口 - clean功能部分。
 * </PRE>
 * 
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * 
 * @version   1.0 2014-10-20
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 * 
 * @goal clean
 * @requiresDependencyResolution runtime
 * @execute phase= "clean"
 */
public class MvnCleanMojo extends org.apache.maven.plugin.AbstractMojo {
	
	/**
	 * The project to create a build for.
	 * 
	 * @parameter default-value="${project}"
	 * @required
	 * @readonly
	 */
	private org.apache.maven.project.MavenProject project;
	
	/**
	 * 构造函数
	 */
	public MvnCleanMojo() {}
	
	/**
	 * 清理脚本
	 */
	public void execute() 
			throws org.apache.maven.plugin.MojoExecutionException {
		
		// 从这里开始才能取到Maven配置，放在构造函数中无法获取
		try {
			initMavenConf();
		} catch (Exception e) {
			LogMgr.error("加载Maven配置失败,程序退出.", e);
			throw new org.apache.maven.plugin.MojoExecutionException(
					"加载Maven配置失败,程序退出", e);
		}
		
		// 执行脚本清理
		Core.getInstn().cleanProject();
	}
	
	/**
	 * Maven调用时初始化配置。
	 * 把所有参数植入到Config，目的是统一接口。
	 */
	private void initMavenConf() throws Exception {
		LogMgr.info("正在初始化[脚本清理]配置...");
		Config.getInstn().setProjectName(project.getArtifactId());
		Config.getInstn().setProjectVersion(project.getVersion());
		Config.getInstn().lockConf();	//锁定配置,禁止再修改
		LogMgr.info("[脚本清理]配置初始化完成.");
	}
}
