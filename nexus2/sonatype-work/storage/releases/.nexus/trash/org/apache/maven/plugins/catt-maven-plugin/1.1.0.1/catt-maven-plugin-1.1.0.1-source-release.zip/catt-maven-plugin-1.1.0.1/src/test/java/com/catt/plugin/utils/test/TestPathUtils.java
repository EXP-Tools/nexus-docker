package com.catt.plugin.utils.test;

import org.junit.Ignore;

@Ignore
public class TestPathUtils {

	//TODO
}
