package com.catt.plugin.core.envm;

/**
 * <PRE>
 * 需要生成脚本的 内联项目名称 定义(主项目除外).
 * 内联项目的名称为全小写,避免歧义.
 * 
 * </PRE>
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * @version   1.0 2014-09-12
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 */
public class ProjectNames {

	/**
	 * ant项目
	 */
	public final static String ANT = "ant";
	
	/**
	 * crypto项目
	 */
	public final static String CRYPTO = "crypto";
	
	/**
	 * autodb项目
	 */
	public final static String AUTODB = "autodb";
	
	/**
	 * startcheck项目
	 */
	public final static String STARTCHECK = "startcheck";
	
	/**
	 * 禁止外部构造，避免误用
	 */
	private ProjectNames() {}
}
