package com.catt.demo;

import com.catt.plugin.Config;
import com.catt.plugin.core.Core;

/**
 * <PRE>
 * 通过 com.catt.plugin.Main 方法直接运行本插件时测试用。
 * 删除不影响其他功能，只是调试时无法再通过 main 方法调用相对麻烦而已。
 * 实际使用时不会用到这个类。
 * 
 * </PRE>
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * @version   1.0 2014-10-20
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 */
@Deprecated
public class Main {

	public static void main(String[] args) {
		System.out.println("调试用，请无视此类。");
		
		try {
			Config.getInstn().loadConf(Config.DEFAULT_CONF_PATH);
			Core.getInstn().cleanProject();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
