package com.catt.plugin.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.catt.plugin.FileNameSearch;
import com.catt.plugin.PackageMojo;

/**
 * <PRE>
 * 插件测试暂时无法做
 * </PRE>
 * 
 * <B>项 目：</B>凯通J2SE开发平台(KTJSDP) <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * 
 * @version 1.0 2014-3-18
 * @author 黄坚：huangjian@gdcattsoft.com
 * @since jdk版本：jdk1.6
 */
@Ignore
public class TestPackageMojo {


	@Test
	public void testPackageMojo() throws Exception {
		invokeAntMojo("package-test");
	}

	/**
	 * Invoke Ant mojo. <br/>
	 * The Maven test project should be in a directory called
	 * <code>testProject</code> in "src/test/resources/unit/" directory. The
	 * Maven test project should be called
	 * <code>"testProject"-plugin-config.xml</code> and should produced
	 * <code>ant-plugin-test.jar</code> as artefact.
	 * 
	 * @param testProject
	 * @throws Exception
	 */
	private void invokeAntMojo(String testProject) throws Exception {
//		File testPom = new File(getBasedir(), "src/test/resources/unit/"
//				+ testProject + "/pom.xml");
//		PackageMojo mojo = (PackageMojo) lookupMojo("package", testPom);
//		mojo.execute();
	}

	@Test
	public void testReplaceFileSeparatorToWin() {
		List<String> list = new ArrayList<String>();
		list.add("/home/catt/abc.jar");
		list.add("com/catt/catt-util/1.0.0/catt-util-1.0.0.jar");
		list.add("org/abc/catt-util/1.0.0/catt-util-1.0.0.jar");
		
		list = new PackageMojo().replaceFileSeparatorToWin(list);
		
		System.out.println(list);
		
		assertEquals(list.get(0), "\\home\\catt\\abc.jar");
		assertEquals(list.get(1), "com\\catt\\catt-util\\1.0.0\\catt-util-1.0.0.jar");
		assertEquals(list.get(2), "org\\abc\\catt-util\\1.0.0\\catt-util-1.0.0.jar");
	}
	
	@Test
	public void testSearchJarWithName() {
		String jarName = null;
		String folder = null;
		String path = null;
		
		jarName = "Catt-allTest-1.2.10.140107.jar";
		folder = "D:\\commonLib";
		
		path = FileNameSearch.searchByFullMatch(jarName, folder);
		System.out.println(path);
	}

}
