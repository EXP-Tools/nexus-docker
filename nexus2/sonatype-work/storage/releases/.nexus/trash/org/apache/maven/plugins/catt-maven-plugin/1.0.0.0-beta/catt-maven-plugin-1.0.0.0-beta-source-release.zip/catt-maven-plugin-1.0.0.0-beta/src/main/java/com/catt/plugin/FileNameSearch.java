package com.catt.plugin;

import java.io.File;

/**
 * <PRE>
 * 搜索目录下的指定文件
 * </PRE>
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * @version   1.0 2014-3-18
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 */
public class FileNameSearch {
	
	/**
	 * DFS搜索文件，返回文件路径。
	 * 包括扩展名在内，完全匹配搜索。
	 * 找到第一个马上返回。
	 *
	 * @param tarFileName 目标文件名
	 * @param curFolder 当前目录名
	 * @return 目标文件的绝对路径，不存在返回 null
	 */
	public static String searchByFullMatch(
			String tarFileName, String curFolder) {
		
		File file = new File(curFolder);
		if(file.isDirectory() == false) {
			return null;
		}
		
		File[] files = file.listFiles();
		if (files == null) {
			return null;
		}
		
		int len = files.length;
		for (int i = 0; i < len; i++) {
			
			if(files[i].isDirectory()) {
				String path = searchByFullMatch(tarFileName, 
						files[i].getAbsolutePath());
				if(path != null) {
					return path;
				}
				
			} else if(files[i].isFile()) {
				if(files[i].getName().endsWith(tarFileName)) {
					return files[i].getAbsolutePath();
				}
			}
		}
		return null;
	}

	/**
	 * DFS搜索文件，返回文件路径。
	 * 正则模糊匹配搜索。
	 * 找到第一个马上返回。
	 *
	 * @param tarFileRegexName 目标文件名的正则式
	 * @param curFolder 当前目录名
	 * @return 目标文件的绝对路径，不存在返回 null
	 */
	public static String searchByRegexMatch(
			String tarFileRegexName, String curFolder) {
		
		File file = new File(curFolder);
		if(file.isDirectory() == false) {
			return null;
		}
		
		File[] files = file.listFiles();
		if (files == null) {
			return null;
		}
		
		int len = files.length;
		for (int i = 0; i < len; i++) {
			
			if(files[i].isDirectory()) {
				String path = searchByRegexMatch(tarFileRegexName, 
						files[i].getAbsolutePath());
				if(path != null) {
					return path;
				}
				
			} else if(files[i].isFile()) {
				if(files[i].getName().matches(tarFileRegexName)) {
					return files[i].getAbsolutePath();
				}
			}
		}
		return null;
	}
	
}
