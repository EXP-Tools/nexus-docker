package com.catt.plugin;

import java.io.File;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.project.MavenProject;

/**
 * <PRE>
 * 清理旧脚本
	start.sh
	start.bat
	stop.sh
	start_monitor.sh
	start_monitor.bat
	autoDB.sh
	autoDB.bat
	version.bat
	version.sh
	crypto.bat
	crypto.sh
	startCheck.bat
	startCheck.sh
 * </PRE>
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * @version   1.0 2014-3-14
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 * 
 * 
 * @goal clean
 * 
 * 
 */
public class CleanMojo extends AbstractMojo {
	
	/**
	 * The project to create a build for.
	 * 
	 * @parameter default-value="${project}"
	 * @required
	 * @readonly
	 */
	private MavenProject project;
	
	/**
	 * 清理脚本
	 */
	public void execute() throws MojoExecutionException {
		getLog().info("[自动生成脚本]插件清理旧脚本开始.");
		String releasePath = getProjectReleasePath(project);
		
		String[] scriptFileNames = {
				"start.sh", 
				"start.bat", 
				"stop.sh", 
				"start_monitor.sh", 
				"start_monitor.bat", 
				"autoDB.sh", 
				"autoDB.bat", 
				"version.bat", 
				"version.sh", 
				"crypto.bat", 
				"crypto.sh", 
				"startCheck.bat", 
				"startCheck.sh"
		};
		
		File file = null;
		String filePath = null;
		for(String fileName : scriptFileNames) {
			filePath = releasePath + File.separator + fileName;
			file = new File(filePath);
			if(false == file.delete()) {
				getLog().warn("旧脚本 [" + filePath + "] 删除失败.请手动执行.");
			}
		}
		
		getLog().info("[自动生成脚本]插件清理旧脚本完成.");
	}
	
	/**
	 * 获取Maven项目的release位置的绝对路径
	 * @param project Maven项目
	 * @return release位置的绝对路径
	 */
	public String getProjectReleasePath(MavenProject project) {
		return project.getBasedir().getAbsolutePath() + 
				File.separator + "target" + File.separator + 
				project.getArtifactId() + "-" + project.getVersion();
	}
}
