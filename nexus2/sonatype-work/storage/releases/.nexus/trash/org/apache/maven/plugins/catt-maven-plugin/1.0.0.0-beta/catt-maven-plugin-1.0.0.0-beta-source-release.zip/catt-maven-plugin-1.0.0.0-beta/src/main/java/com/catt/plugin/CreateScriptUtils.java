package com.catt.plugin;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.catt.util.io.FileUtils;

/**
 * <PRE>
 * 生成脚本
	start.sh
	start.bat
	stop.sh
	start_monitor.sh
	start_monitor.bat
	autoDB.sh
	autoDB.bat
	version.bat
	version.sh
	crypto.bat
	crypto.sh
	startCheck.bat
	startCheck.sh
 * </PRE>
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * @version   1.0 2014-3-14
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 */
public class CreateScriptUtils {
	
	/**
	 * win 换行符
	 */
	public final static String WIN_LINE_END = "\r\n"; 
	
	/**
	 * win Jar包分隔符
	 */
	public final static String WIN_LINE_SEP = ";"; 
	
	/**
	 * linux 换行符
	 */
	public final static String LINUX_LINE_END = "\n"; 
	
	/**
	 * linux Jar包分隔符
	 */
	public final static String LINUX_LINE_SEP = ":";
	
	/**
	 * 生成 start.bat 脚本
	 * @param releasePath 生成脚本位置
	 * @param projectName 项目名称
	 * @param prefixPaths 项目引用jar包路径的路径前缀
	 * @param libPaths 项目引用jar包路径
	 * @param mainClass 项目main方法类路径
	 * @param charset 脚本字符集
	 * @return 0成功 1失败
	 */
	public static int createWinStartScript(String releasePath, 
			String projectName, String[] prefixPaths, 
			List<String> libPaths, String mainClass, String charset) {
		int isSuccess = 0;
		String fileName = "start.bat";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("@echo off").append(WIN_LINE_END);
		fileContent.append("title ").append(projectName).append(WIN_LINE_END);
		fileContent.append(WIN_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("set lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(WIN_LINE_END);
		}
		fileContent.append(WIN_LINE_END);
		
		// 设置线程名称
		fileContent.append("java -D").append(projectName);
		
		// 设置引用jar包
		fileContent.append(" -cp ");
		for(String libPath : libPaths) {
			fileContent.append(libPath).append(WIN_LINE_SEP);
		}
		
		// 设置引用mainClass和错误日志
		fileContent.append(" ").append(mainClass);
		fileContent.append(" 2>err.log").append(WIN_LINE_END);
		fileContent.append("pause").append(WIN_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 生成 start.sh 脚本
	 * @param releasePath 生成脚本位置
	 * @param projectName 项目名称
	 * @param prefixPaths 项目引用jar包路径的路径前缀
	 * @param libPaths 项目引用jar包路径
	 * @param mainClass 项目main方法类路径
	 * @param charset 脚本字符集
	 * @return 0成功 1失败
	 */
	public static int createLinuxStartScript(String releasePath, 
			String projectName, String[] prefixPaths, 
			List<String> libPaths, String mainClass, String charset) {
		int isSuccess = 0;
		String fileName = "start.sh";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("﻿#!/bin/bash").append(LINUX_LINE_END);
		fileContent.append("# ").append(projectName).append(LINUX_LINE_END);
		fileContent.append(LINUX_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("export lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(LINUX_LINE_END);
		}
		fileContent.append(LINUX_LINE_END);
				
		// 设置线程ID
		fileContent.append("PID=`ps -ef|grep ").append(projectName);
		fileContent.append("|grep -v grep|awk '{print $2}'`");
		fileContent.append(LINUX_LINE_END);
		
		// 设置线程重复启动判断
		fileContent.append("if [ -z $PID ];then").append(LINUX_LINE_END);
		
		// 设置线程名称
		fileContent.append("    java -D").append(projectName);
		
		// 设置引用jar包
		fileContent.append(" -cp ");
		for(String libPath : libPaths) {
			fileContent.append(libPath).append(LINUX_LINE_SEP);
		}
		
		// 设置引用mainClass、运行日志和错误日志
		fileContent.append(" ").append(mainClass);
		fileContent.append(" >/dev/null 2>err.log &").append(LINUX_LINE_END);
		
		// 设置线程重复启动时的处理
		fileContent.append("else").append(LINUX_LINE_END);
		fileContent.append("    echo \"The program ").append(projectName);
		fileContent.append(" has been running.Please stop it firstly.\"");
		fileContent.append(LINUX_LINE_END).append("fi").append(LINUX_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 生成 start_monitor.bat 脚本
	 * @param releasePath 生成脚本位置
	 * @param projectName 项目名称
	 * @param prefixPaths 项目引用jar包路径的路径前缀
	 * @param libPaths 项目引用jar包路径
	 * @param mainClass 项目main方法类路径
	 * @param charset 脚本字符集
	 * @return 0成功 1失败
	 */
	public static int createWinStartMonitorScript(String releasePath, 
			String projectName, String[] prefixPaths, 
			List<String> libPaths, String mainClass, String charset) {
		int isSuccess = 0;
		String fileName = "start_monitor.bat";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("@echo off").append(WIN_LINE_END);
		fileContent.append("title ").append(projectName).append(WIN_LINE_END);
		fileContent.append(WIN_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("set lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(WIN_LINE_END);
		}
		fileContent.append(WIN_LINE_END);
				
		// 设置线程名称
		fileContent.append("java -D").append(projectName);
		
		// 设置监控参数
		fileContent.append(" -Dcom.sun.management.jmxremote.port=9004");
		fileContent.append(" -Dcom.sun.management.jmxremote.ssl=\"false\"");
		fileContent.append(" -Dcom.sun.management.jmxremote.authenticate=\"false\"");
		fileContent.append(" -verbose:gc -Xloggc:gc.log");
				
		// 设置引用jar包
		fileContent.append(" -cp ");
		for(String libPath : libPaths) {
			fileContent.append(libPath).append(WIN_LINE_SEP);
		}
		
		// 设置引用mainClass和错误日志
		fileContent.append(" ").append(mainClass);
		fileContent.append(" 2>err.log").append(WIN_LINE_END);
		fileContent.append("pause").append(WIN_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 生成 start_monitor.sh 脚本
	 * @param releasePath 生成脚本位置
	 * @param projectName 项目名称
	 * @param prefixPaths 项目引用jar包路径的路径前缀
	 * @param libPaths 项目引用jar包路径
	 * @param mainClass 项目main方法类路径
	 * @param charset 脚本字符集
	 * @return 0成功 1失败
	 */
	public static int createLinuxStartMonitorScript(String releasePath, 
			String projectName, String[] prefixPaths, 
			List<String> libPaths, String mainClass, String charset) {
		int isSuccess = 0;
		String fileName = "start_monitor.sh";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("﻿#!/bin/bash").append(LINUX_LINE_END);
		fileContent.append("# ").append(projectName).append(LINUX_LINE_END);
		fileContent.append(LINUX_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("export lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(LINUX_LINE_END);
		}
		fileContent.append(LINUX_LINE_END);
				
		// 设置线程ID
		fileContent.append("PID=`ps -ef|grep ").append(projectName);
		fileContent.append("|grep -v grep|awk '{print $2}'`");
		fileContent.append(LINUX_LINE_END);
		
		// 设置线程存在性判断
		fileContent.append("if [ -z $PID ];then").append(LINUX_LINE_END);
		
		// 设置线程名称
		fileContent.append("    java -D").append(projectName);
		
		// 设置监控参数
		fileContent.append(" -Dcom.sun.management.jmxremote.port=9004");
		fileContent.append(" -Dcom.sun.management.jmxremote.ssl=\"false\"");
		fileContent.append(" -Dcom.sun.management.jmxremote.authenticate=\"false\"");
		fileContent.append(" -verbose:gc -Xloggc:gc.log");
				
		// 设置引用jar包
		fileContent.append(" -cp ");
		for(String libPath : libPaths) {
			fileContent.append(libPath).append(LINUX_LINE_SEP);
		}
		
		// 设置引用mainClass、运行日志和错误日志
		fileContent.append(" ").append(mainClass);
		fileContent.append(" >/dev/null 2>err.log &").append(LINUX_LINE_END);
		
		// 设置线程重复启动时的处理
		fileContent.append("else").append(LINUX_LINE_END);
		fileContent.append("    echo \"The program ").append(projectName);
		fileContent.append(" has been running.Please stop it firstly.\"");
		fileContent.append(LINUX_LINE_END).append("fi").append(LINUX_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 生成 stop.sh 脚本
	 * @param releasePath 生成脚本位置
	 * @param projectName 项目名称
	 * @param charset 脚本字符集
	 * @return 0成功 1失败
	 */
	public static int createLinuxStopScript(String releasePath, 
			String projectName, String charset) {
		int isSuccess = 0;
		String fileName = "stop.sh";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("﻿#!/bin/bash").append(LINUX_LINE_END);
		fileContent.append("# ").append(projectName).append(LINUX_LINE_END);
		fileContent.append(LINUX_LINE_END);
		
		// 设置线程ID
		fileContent.append("PID=`ps -ef|grep ").append(projectName);
		fileContent.append("|grep -v grep|awk '{print $2}'`");
		fileContent.append(LINUX_LINE_END);
		
		// 设置线程存在性判断
		fileContent.append("if [ -z $PID ];then").append(LINUX_LINE_END);
		
		// 设置停止线程操作
		fileContent.append("    kill -9 $PID").append(LINUX_LINE_END);
		fileContent.append("    echo \"Kill the program ").append(projectName);
		fileContent.append(" successfully.").append(LINUX_LINE_END);
		
		
		// 设置线程重复启动时的处理
		fileContent.append("else").append(LINUX_LINE_END);
		fileContent.append("    echo \"The program ").append(projectName);
		fileContent.append(" has been stoped.\"");
		fileContent.append(LINUX_LINE_END).append("fi").append(LINUX_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 生成 crypto.bat 脚本
	 * @param releasePath 生成脚本位置
	 * @param prefixPaths 项目引用jar包路径的路径前缀
	 * @param libPaths 项目引用jar包路径
	 * @param charset 脚本字符集
	 * @param scriptType 脚本类型
	 * @return 0成功 1失败
	 */
	public static int createWinCryptoScript(String releasePath, 
			String[] prefixPaths, List<String> libPaths, 
			String charset, String scriptType) {
		int isSuccess = 0;
		String fileName = "crypto.bat";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("@echo off").append(WIN_LINE_END);
		fileContent.append("title CryptoUtils").append(WIN_LINE_END);
		fileContent.append(WIN_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("set lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(WIN_LINE_END);
		}
		fileContent.append(WIN_LINE_END);
				
		// 设置VM内存、线程名称
		fileContent.append("java -Xms16m -Xmx32m -DCryptoUtils");
				
		// 设置引用jar包
		String utilJarPath = getUtilJarPath(prefixPaths, libPaths, scriptType);
		fileContent.append(" -cp ").append(utilJarPath).append(WIN_LINE_SEP);
		
		// 设置引用mainClass
		fileContent.append(" com.catt.util.crypto.CryptoUtils");
		fileContent.append(WIN_LINE_END);
		fileContent.append("pause").append(WIN_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 生成 crypto.sh 脚本
	 * @param releasePath 生成脚本位置
	 * @param prefixPaths 项目引用jar包路径的路径前缀
	 * @param libPaths 项目引用jar包路径
	 * @param charset 脚本字符集
	 * @param scriptType 脚本类型
	 * @return 0成功 1失败
	 */
	public static int createLinuxCryptoScript(String releasePath, 
			String[] prefixPaths, List<String> libPaths, 
			String charset, String scriptType) {
		int isSuccess = 0;
		String fileName = "crypto.sh";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("﻿#!/bin/bash").append(LINUX_LINE_END);
		fileContent.append("# CryptoUtils").append(LINUX_LINE_END);
		fileContent.append(LINUX_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("export lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(LINUX_LINE_END);
		}
		fileContent.append(LINUX_LINE_END);
				
		// 设置线程ID
		fileContent.append("PID=`ps -ef|grep CryptoUtils");
		fileContent.append("|grep -v grep|awk '{print $2}'`");
		fileContent.append(LINUX_LINE_END);
		
		// 设置线程存在性判断
		fileContent.append("if [ -z $PID ];then").append(LINUX_LINE_END);
		
		// 设置线程名称
		fileContent.append("    java -Xms16m -Xmx32m -DCryptoUtils");
		
		// 设置引用jar包
		String utilJarPath = getUtilJarPath(prefixPaths, libPaths, scriptType);
		fileContent.append(" -cp ").append(utilJarPath).append(LINUX_LINE_SEP);
		
		// 设置引用mainClass和错误日志
		fileContent.append(" com.catt.util.crypto.CryptoUtils");
		fileContent.append(LINUX_LINE_END);
		
		// 设置线程重复启动时的处理
		fileContent.append("else").append(LINUX_LINE_END);
		fileContent.append("    echo \"The program CryptoUtils");
		fileContent.append(" has been running.Please stop it firstly.\"");
		fileContent.append(LINUX_LINE_END).append("fi").append(LINUX_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 生成 version.bat 脚本
	 * @param releasePath 生成脚本位置
	 * @param projectName 项目名称
	 * @param version 项目版本
	 * @param prefixPaths 项目引用jar包路径的路径前缀
	 * @param libPaths 项目引用jar包路径
	 * @param versionClass 项目Version类路径
	 * @param charset 脚本字符集
	 * @param scriptType 脚本类型
	 * @return 0成功 1失败
	 */
	public static int createWinVersionScript(String releasePath, 
			String projectName, String version, 
			String[] prefixPaths, List<String> libPaths, 
			String versionClass, String charset, String scriptType) {
		int isSuccess = 0;
		String fileName = "version.bat";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("@echo off").append(WIN_LINE_END);
		fileContent.append("title ").append(projectName).append(WIN_LINE_END);
		fileContent.append(WIN_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("set lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(WIN_LINE_END);
		}
		fileContent.append(WIN_LINE_END);
		
		// 设置引用jar包
		String proJarPath = ".\\lib\\" + projectName + "-" + version + ".jar";
		for(String libPath : libPaths) {
			if(libPath.matches("^.*" + projectName + "-" + 
					version + "\\.jar*$")) {
				proJarPath = libPath;
				break;
			}
		}
		String utilJarPath = getUtilJarPath(prefixPaths, libPaths, scriptType);
		fileContent.append("java -cp ");
		fileContent.append(proJarPath).append(WIN_LINE_SEP);
		fileContent.append(utilJarPath).append(WIN_LINE_SEP);
		
		// 设置引用versionClass
		fileContent.append(" ").append(versionClass).append(" -V");
		fileContent.append(WIN_LINE_END);
		fileContent.append("pause").append(WIN_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 生成 version.sh 脚本
	 * @param releasePath 生成脚本位置
	 * @param projectName 项目名称
	 * @param version 项目版本
	 * @param prefixPaths 项目引用jar包路径的路径前缀
	 * @param libPaths 项目引用jar包路径
	 * @param versionClass 项目Version类路径
	 * @param charset 脚本字符集
	 * @param scriptType 脚本类型
	 * @return 0成功 1失败
	 */
	public static int createLinuxVersionScript(String releasePath, 
			String projectName, String version, 
			String[] prefixPaths, List<String> libPaths, 
			String versionClass, String charset, String scriptType) {
		int isSuccess = 0;
		String fileName = "version.sh";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("﻿#!/bin/bash").append(LINUX_LINE_END);
		fileContent.append("# ").append(projectName).append(LINUX_LINE_END);
		fileContent.append(LINUX_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("export lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(LINUX_LINE_END);
		}
		fileContent.append(LINUX_LINE_END);
				
		// 设置引用jar包
		String proJarPath = "./lib/" + projectName + "-" + version + ".jar";
		for(String libPath : libPaths) {
			if(libPath.matches("^.*" + projectName + "-" + 
					version + "\\.jar*$")) {
				proJarPath = libPath;
				break;
			}
		}
		String utilJarPath = getUtilJarPath(prefixPaths, libPaths, scriptType);
		fileContent.append("java -cp ");
		fileContent.append(proJarPath).append(LINUX_LINE_SEP);
		fileContent.append(utilJarPath).append(LINUX_LINE_SEP);
		
		// 设置引用versionClass
		fileContent.append(" ").append(versionClass);
		fileContent.append(" -V").append(LINUX_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
		
	}
	
	/**
	 * 生成 startCheck.bat 脚本
	 * @param releasePath 生成脚本位置
	 * @param prefixPaths startCheck工具引用jar包路径的路径前缀
	 * @param libPaths startCheck工具插件引用jar包路径
	 * @param charset 脚本字符集
	 * @return 0成功 1失败
	 */
	public static int createWinStartCheckScript(String releasePath, 
			String[] prefixPaths, List<String> libPaths, String charset) {
		int isSuccess = 0;
		String fileName = "startCheck.bat";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("@echo off").append(WIN_LINE_END);
		fileContent.append("title KTJSDP-startCheck").append(WIN_LINE_END);
		fileContent.append(WIN_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("set lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(WIN_LINE_END);
		}
		fileContent.append(WIN_LINE_END);
				
		// 设置线程名称
		fileContent.append("java -Xms64m -Xmx512m -DstartCheck");
		
		// 设置引用jar包
		fileContent.append(" -cp ");
		for(String libPath : libPaths) {
			fileContent.append(libPath).append(WIN_LINE_SEP);
		}
		
		// 设置引用mainClass和错误日志
		fileContent.append(" com.catt.pub.start.check.StartCheckMain");
		fileContent.append(" 2>err.log").append(WIN_LINE_END);
		fileContent.append("pause").append(WIN_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 生成 startCheck.sh 脚本
	 * @param releasePath 生成脚本位置
	 * @param prefixPaths startCheck工具引用jar包路径的路径前缀
	 * @param libPaths startCheck工具插件引用jar包路径
	 * @param charset 脚本字符集
	 * @return 0成功 1失败
	 */
	public static int createLinuxStartCheckScript(String releasePath, 
			String[] prefixPaths, List<String> libPaths, String charset) {
		int isSuccess = 0;
		String fileName = "startCheck.sh";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("﻿#!/bin/bash").append(LINUX_LINE_END);
		fileContent.append("# KTJSDP-startCheck").append(LINUX_LINE_END);
		fileContent.append(LINUX_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("export lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(LINUX_LINE_END);
		}
		fileContent.append(LINUX_LINE_END);
				
		// 设置线程ID
		fileContent.append("PID=`ps -ef|grep startCheck");
		fileContent.append("|grep -v grep|awk '{print $2}'`");
		fileContent.append(LINUX_LINE_END);
		
		// 设置线程重复启动判断
		fileContent.append("if [ -z $PID ];then").append(LINUX_LINE_END);
		
		// 设置线程名称
		fileContent.append("    java -Xms64m -Xmx512m -DstartCheck");
		
		// 设置引用jar包
		fileContent.append(" -cp ");
		for(String libPath : libPaths) {
			fileContent.append(libPath).append(LINUX_LINE_SEP);
		}
		
		// 设置引用mainClass和错误日志
		fileContent.append(" com.catt.pub.start.check.StartCheckMain");
		fileContent.append(" 2>err.log &").append(LINUX_LINE_END);
		
		// 设置线程重复启动时的处理
		fileContent.append("else").append(LINUX_LINE_END);
		fileContent.append("    echo \"The program startcheck");
		fileContent.append(" has been running.Please stop it firstly.\"");
		fileContent.append(LINUX_LINE_END).append("fi").append(LINUX_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 生成 autoDB.bat 脚本
	 * @param releasePath 生成脚本位置
	 * @param prefixPaths autoDB工具引用jar包路径的路径前缀
	 * @param libPaths autoDB工具插件引用jar包路径
	 * @param charset 脚本字符集
	 * @return 0成功 1失败
	 */
	public static int createWinAutoDBScript(String releasePath, 
			String[] prefixPaths, List<String> libPaths, String charset) {
		int isSuccess = 0;
		String fileName = "autoDB.bat";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("@echo off").append(WIN_LINE_END);
		fileContent.append("title KTJSDP-autoDB").append(WIN_LINE_END);
		fileContent.append(WIN_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("set lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(WIN_LINE_END);
		}
		fileContent.append(WIN_LINE_END);
				
		// 设置线程名称
		fileContent.append("java -Xms64m -Xmx512m -DautoDB");
		
		// 设置引用jar包
		fileContent.append(" -cp ");
		for(String libPath : libPaths) {
			fileContent.append(libPath).append(WIN_LINE_SEP);
		}
		
		// 设置引用mainClass和错误日志
		fileContent.append(" com.catt.pub.update.script.ScriptUpdateMain");
		fileContent.append(" 2>err.log").append(WIN_LINE_END);
		fileContent.append("pause").append(WIN_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
		
	}
	
	/**
	 * 生成 autoDB.sh 脚本
	 * @param releasePath 生成脚本位置
	 * @param prefixPaths autoDB工具引用jar包路径的路径前缀
	 * @param libPaths autoDB工具插件引用jar包路径
	 * @param charset 脚本字符集
	 * @return 0成功 1失败
	 */
	public static int createLinuxAutoDBScript(String releasePath, 
			String[] prefixPaths, List<String> libPaths, String charset) {
		int isSuccess = 0;
		String fileName = "autoDB.sh";
		StringBuffer fileContent = new StringBuffer();
		
		// 设置标题
		fileContent.append("﻿#!/bin/bash").append(LINUX_LINE_END);
		fileContent.append("# KTJSDP-autoDB").append(LINUX_LINE_END);
		fileContent.append(LINUX_LINE_END);
		
		// 设置目录前缀变量
		int size = prefixPaths.length;
		for(int i = 0; i < size; i++) {
			fileContent.append("export lib").append(i);
			fileContent.append("=").append(prefixPaths[i]);
			fileContent.append(LINUX_LINE_END);
		}
		fileContent.append(LINUX_LINE_END);
				
		// 设置线程ID
		fileContent.append("PID=`ps -ef|grep autoDB");
		fileContent.append("|grep -v grep|awk '{print $2}'`");
		fileContent.append(LINUX_LINE_END);
		
		// 设置线程重复启动判断
		fileContent.append("if [ -z $PID ];then").append(LINUX_LINE_END);
		
		// 设置线程名称
		fileContent.append("    java -Xms64m -Xmx512m -DautoDB");
		
		// 设置引用jar包
		fileContent.append(" -cp ");
		for(String libPath : libPaths) {
			fileContent.append(libPath).append(LINUX_LINE_SEP);
		}
		
		// 设置引用mainClass和错误日志
		fileContent.append(" com.catt.pub.update.script.ScriptUpdateMain");
		fileContent.append(" 2>err.log &").append(LINUX_LINE_END);
		
		// 设置线程重复启动时的处理
		fileContent.append("else").append(LINUX_LINE_END);
		fileContent.append("    echo \"The program autoDB");
		fileContent.append(" has been running.Please stop it firstly.\"");
		fileContent.append(LINUX_LINE_END).append("fi").append(LINUX_LINE_END);
		
		// 生成文件
		try {
			FileUtils.write(new File(releasePath + File.separator + fileName), 
					fileContent.toString(), charset, false);
		} catch (IOException e) {
			isSuccess = 1;
			String errMsg = "脚本 [" + fileName + "] 创建失败.\r\n错误原因:[" + e + "]";
//			JOptionPane.showMessageDialog(null, errMsg); 
			System.err.println(errMsg);
		}
		return isSuccess;
	}
	
	/**
	 * 获取catt-utils.jar包的引用路径
	 * 
	 * @param prefixPaths 路径前缀数组，0为lib，1为commonLib，2为maven仓库
	 * @param libPaths 项目引用的依赖包路径集
	 * @param scriptType 指定生成的依赖脚本类型，lib、commonLib或maven
	 * @return catt-utils.jar包的引用路径
	 */
	private static String getUtilJarPath(String[] prefixPaths, 
			List<String> libPaths, String scriptType) {
		
		//默认值引用Maven仓库中的非快照版
		String utilJarPath = FileNameSearch.searchByRegexMatch(
				"(?i)^(?=catt-utils)((?!SNAPSHOT).)*jar$", prefixPaths[2]);
		
		//若脚本类型为commomLib，则修正为指向commomLib
		if("commomLib".equalsIgnoreCase(scriptType)) {
			utilJarPath = FileNameSearch.searchByRegexMatch(
					"catt-utils.jar", prefixPaths[1]);		
		}
		
		//若项目自身已引用utils包,则以此路径为最优先（项目引用的可能是旧包名称）
		for(String libPath : libPaths) {
			if(libPath.matches("(?i)^.*Catt-util.*$")) {
				utilJarPath = libPath;
				break;
			}
		}
		return utilJarPath;
	}
	
}
