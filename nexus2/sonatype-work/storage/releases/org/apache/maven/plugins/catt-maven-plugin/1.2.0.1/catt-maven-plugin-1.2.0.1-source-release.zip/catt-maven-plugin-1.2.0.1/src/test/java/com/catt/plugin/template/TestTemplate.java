package com.catt.plugin.template;

import org.junit.Ignore;

@Ignore
public class TestTemplate {

	//TODO
}
