package com.catt.plugin.core.builder.impl;

import java.util.List;

import com.catt.plugin.Config;
import com.catt.plugin.core.builder.IBuilder;
import com.catt.plugin.core.builder.ProjectScript;
import com.catt.plugin.core.envm.FinalParams;
import com.catt.plugin.core.envm.ProjectNames;
import com.catt.plugin.core.envm.ScriptNames;
import com.catt.plugin.core.manager.JarMgr;
import com.catt.plugin.path.PathTree;
import com.catt.plugin.template.Template;
import com.catt.plugin.template.envm.Placeholders;
import com.catt.plugin.template.envm.TemplateFiles;
import com.catt.plugin.utils.StandUtils;

/**
 * <PRE>
 * Crypto项目脚本构建器
 * </PRE>
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * @version   1.0 2014-9-19
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 */
final public class CryptoBuilder implements IBuilder {

	/**
	 * Crypto项目脚本容器
	 */
	private ProjectScript ps;
	
	/**
	 * Crypto项目名称
	 */
	private String prjName;
	
	/**
	 * main类路径
	 */
	private final String MAIN_CLASS = 
			"com.catt.util.crypto.CryptoUtils";
	
	/**
	 * 构造函数
	 */
	public CryptoBuilder() {
		this.prjName = ProjectNames.CRYPTO;
		this.ps = new ProjectScript(prjName);
	}
	
	@Override
	public ProjectScript constructScripts() {
		return ps;
	}

	@Override
	public void buildDosStart() {
		StringBuilder sb = new StringBuilder();
		
		//获取依赖包集合
		List<String> jarPaths = JarMgr.getInstn().getWinJarPaths(prjName);
		
		//构造路径树,获取路径前缀集合
		PathTree pt = new PathTree("DOS-" + prjName);
		pt.addMore(jarPaths);
		List<String> pathPres = pt.getWinPathPrefixSet(
				Config.getInstn().getPathPrefixMode());
		int preNum = pathPres.size();
		
		/////////////////////////////////////////////////////
		// 加载模板
		Template tpl = new Template(ScriptNames.CRYPTO_BAT);
		tpl.read(TemplateFiles.START_TEMPLATE_DOS);
		
		/////////////////////////////////////////////////////
		// 设置项目名称
		tpl.set(Placeholders.PROJECT_NAME, prjName);
		
		// 设置线程后缀
		tpl.set(Placeholders.THREAD_SUFFIX, "");
				
		// 设置路径前缀变量
		sb.setLength(0);
		for(int idx = 0; idx < preNum; idx++) {
			sb.append("set lib").append(idx);
			sb.append('=').append(pathPres.get(idx)).append("\r\n");
		}
		tpl.set(Placeholders.VARIABLE_DECLARATION, sb.toString());
		
		// 设置JDK路径
		tpl.set(Placeholders.JDK_PATH, FinalParams.JDK_PATH);
		
		// 设置JDK参数
		sb.setLength(0);
		sb.append("-Xms").append(Config.getInstn().getXms()).append(' ');
		sb.append("-Xmx").append(Config.getInstn().getXmx()).append(' ');
		sb.append(Config.getInstn().getJdkParams());
		tpl.set(Placeholders.JDK_PARAMS, sb.toString());
		
		// 设置CP
		sb.setLength(0);
		for(String jarPath : jarPaths) {
			for(int i = 0; i < preNum; i++) {
				String pathPre = pathPres.get(i);
				if(jarPath.startsWith(pathPre)) {
					jarPath = jarPath.replace(pathPre, "%lib" + i + "%");
					break;
				}
			}
			sb.append(jarPath).append(';');
		}
		tpl.set(Placeholders.CLASSPATH, sb.toString());
		
		// 设置main方法
		tpl.set(Placeholders.MAIN_METHOD, MAIN_CLASS);
		
		// 设置main方法入参
		tpl.set(Placeholders.MAIN_METHOD_PARAMS, "");
		
		// 设置标准流和异常流
		tpl.set(Placeholders.STDOUT_CTRL, "");
		tpl.set(Placeholders.ERROUT_CTRL, "2>err.log");
		
		/////////////////////////////////////////////////////
		//标准化脚本内容,并将其植入到项目脚本容器,等待构造
		String scriptContent = StandUtils.unix2dos(tpl.getContent());
		ps.addScript(ScriptNames.CRYPTO_BAT, scriptContent);
	}

	@Override
	public void buildUnixStart() {
		StringBuilder sb = new StringBuilder();
		
		//获取依赖包集合
		List<String> jarPaths = JarMgr.getInstn().getLinuxJarPaths(prjName);
		
		//构造路径树,获取路径前缀集合
		PathTree pt = new PathTree("LINUX-" + prjName);
		pt.addMore(jarPaths);
		List<String> pathPres = pt.getLinuxPathPrefixSet(
				Config.getInstn().getPathPrefixMode());
		int preNum = pathPres.size();
		
		/////////////////////////////////////////////////////
		// 加载模板
		Template tpl = new Template(ScriptNames.CRYPTO_SH);
		tpl.read(TemplateFiles.START_TEMPLATE_UNIX);
		
		/////////////////////////////////////////////////////
		// 设置项目名称
		tpl.set(Placeholders.PROJECT_NAME, prjName);
		
		// 设置线程后缀
		tpl.set(Placeholders.THREAD_SUFFIX, "");
				
		// 设置路径前缀变量
		sb.setLength(0);
		for(int idx = 0; idx < preNum; idx++) {
			sb.append("export lib").append(idx);
			sb.append('=').append(pathPres.get(idx)).append("\n");
		}
		tpl.set(Placeholders.VARIABLE_DECLARATION, sb.toString());
		
		// 设置JDK路径
		tpl.set(Placeholders.JDK_PATH, FinalParams.JDK_PATH);
		
		// 设置JDK参数
		sb.setLength(0);
		sb.append("-Xms").append(Config.getInstn().getXms()).append(' ');
		sb.append("-Xmx").append(Config.getInstn().getXmx()).append(' ');
		sb.append(Config.getInstn().getJdkParams());
		tpl.set(Placeholders.JDK_PARAMS, sb.toString());
		
		// 设置CP
		sb.setLength(0);
		for(String jarPath : jarPaths) {
			for(int i = 0; i < preNum; i++) {
				String pathPre = pathPres.get(i);
				if(jarPath.startsWith(pathPre)) {
					jarPath = jarPath.replace(pathPre, "$lib" + i);
					break;
				}
			}
			sb.append(jarPath).append(':');
		}
		tpl.set(Placeholders.CLASSPATH, sb.toString());
		
		// 设置main方法
		tpl.set(Placeholders.MAIN_METHOD, MAIN_CLASS);
		
		// 设置main方法入参
		tpl.set(Placeholders.MAIN_METHOD_PARAMS, "");
		
		// 设置标准流和异常流
		tpl.set(Placeholders.STDOUT_CTRL, ">/dev/null");
		tpl.set(Placeholders.ERROUT_CTRL, "2>err.log");
		
		/////////////////////////////////////////////////////
		//标准化脚本内容,并将其植入到项目脚本容器,等待构造
		String scriptContent = StandUtils.dos2unix(tpl.getContent());
		ps.addScript(ScriptNames.CRYPTO_SH, scriptContent);
	}

	@Override
	public void buildUnixStop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildDosVersion() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildUnixVersion() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildDosMonitor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildUnixMonitor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildAntStart() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buildAntConf() {
		// TODO Auto-generated method stub
		
	}

}
