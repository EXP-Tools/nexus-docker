package com.catt.plugin;

import com.catt.plugin.core.Core;
import com.catt.plugin.core.manager.LogMgr;

/**
 * <PRE>
 * 自动创建脚本插件:非Maven调用入口
 * </PRE>
 * <B>项    目：</B>凯通J2SE开发平台(KTJSDP)
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * @version   1.0 2014-9-16
 * @author    廖权斌：liaoquanbin@gdcattsoft.com
 * @since     jdk版本：jdk1.6
 */
public class Main {

	/**
	 * 非maven外部调用入口
	 * @param args 入参表，创建各种脚本的启动脚本的配置文件路径（此启动脚本的配置文件就是其自身）。
	 */
	public static void main(String[] args) {
		if(args == null || args.length < 1) {
			args = new String[] {
					Config.DEFAULT_CONF_PATH
			};
		}
		
		LogMgr.info("正在初始化配置...");
		Config.getInstn().loadConf(args[0]);//加载配置
		Config.getInstn().lockConf();		//锁定配置,禁止再修改
		LogMgr.info("配置初始化完成:" + Config.getInstn().toPrintKV());
		
		try {
			Core.getInstn().cleanProject();		//先清理
			Core.getInstn().packageProject();	//再打包
			
		} catch (Exception e) {
			LogMgr.error("[自动创建脚本插件]发生致命性异常,程序退出.", e);
			System.exit(1);
		}
	}
	
}
