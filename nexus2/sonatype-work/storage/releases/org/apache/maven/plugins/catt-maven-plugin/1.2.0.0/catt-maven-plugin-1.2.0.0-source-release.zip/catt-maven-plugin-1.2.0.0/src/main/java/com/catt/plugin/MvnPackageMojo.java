package com.catt.plugin;


import com.catt.plugin.core.Core;
import com.catt.plugin.core.manager.JarLoader;
import com.catt.plugin.core.manager.LogMgr;

/**
 * <PRE>
 * 自动创建脚本插件:Maven调用入口 - package功能部分。
 * 
 * 说明：根据脚本类型，自动生成J2SE项目的启动、停止、启动检查等脚本。
 * 
 * 		该插件在package生命周期后运行execute phase
 * 		运行插件前需要进行jar依赖分析requiresDependencyResolution
 * 
 * </PRE>
 * 
 * <B>项 目：</B>凯通J2SE开发平台(KTJSDP) 
 * <B>技术支持：</B>广东凯通软件开发技术有限公司 (c) 2014
 * 
 * @version 1.0 2014-10-20
 * @author 廖权斌：liaoquanbin@gdcattsoft.com
 * @since jdk版本：jdk1.6
 * 
 * @goal install
 * @requiresDependencyResolution runtime
 * @execute phase= "install"
 */
public class MvnPackageMojo extends org.apache.maven.plugin.AbstractMojo {

	/**
	 * The project to create a build for.
	 * 
	 * @parameter default-value="${project}"
	 * @required
	 * @readonly
	 */
	private org.apache.maven.project.MavenProject project;

	/**
	 * <PRE>
	 * 脚本类型，默认脚本引用maven仓库jar的相对路径；
	 * 类型：maven|lib|commonLib
	 * </PRE>
	 * 
	 * @parameter default-value="maven"
	 * @required
	 */
	private String scriptType;
	
	/**
	 * linux默认lib目录路径
	 * 
	 * @parameter default-value="./lib"
	 * @required
	 */
	private String linuxLibPath;
	
	/**
	 * win默认lib目录路径
	 * 
	 * @parameter default-value=".\\lib"
	 * @required
	 */
	private String winLibPath;
	
	
	/**
	 * win默认commonLib目录路径
	 * 
	 * @parameter default-value="D:\\commonLib"
	 * @required
	 */
	private String winCommonLibPath;
	
	/**
	 * linux默认commonLib目录路径
	 * 
	 * @parameter default-value="/home/cattsoft/commonLib"
	 * @required
	 */
	private String linuxCommonLibPath;
	
	
	/**
	 * win默认maven仓库路径
	 * 
	 * @parameter default-value="${settings.localRepository}"
	 * @required
	 */
	private String winMavenLibPath;
	
	/**
	 * linux默认maven仓库路径
	 * 
	 * @parameter default-value="/home/cattsoft/mavenRepository"
	 * @required
	 */
	private String linuxMavenLibPath;
	
	
	/**
	 * 项目启动类路径
	 * 
	 * @parameter default-value="com.catt.demo.Main"
	 * @required
	 */
	private String mainClass;
	
	/**
	 * 项目版本类路径
	 * 
	 * @parameter default-value="com.catt.demo.Version"
	 * @required
	 */
	private String versionClass;
	
	/**
	 * 项目编码
	 * 
	 * @parameter default-value="UTF-8"
	 * @required
	 */
	private String charset;

	/**
	 * 默认分配JVM堆空间
	 * 
	 * @parameter default-value="64m"
	 * @required
	 */
	private String xms;
	
	/**
	 * 最大分配JVM堆空间
	 * 
	 * @parameter default-value="128m"
	 * @required
	 */
	private String xmx;

	/**
	 * jdk参数，若非空则会【附加】到所有脚本的JDK参数表中
	 * 
	 * @parameter default-value=" "
	 * @required
	 */
	private String jdkParams;
	
	/**
	 * 路径前缀模式：
	 * 1：提取尽可能少的路径前缀：各路径中相同的节点至少出现2次以上才会被提取前缀，子前缀压缩。
	 * 2：提取标准数量的路径前缀：路径中同层同名的节点至少出现2次以上才会被提取前缀，相同前缀压缩。
	 * 3：提取尽可能多的路径前缀：所有路径都会被提取前缀，相同前缀压缩。
	 * 
	 * @parameter default-value="2"
	 * @required
	 */
	private String pathPrefixMode;
	
	/**
	 * 是否创建start.bat/sh stop.sh start_monitor.bat/sh version.bat/sh
	 * 
	 * @parameter default-value="true"
	 * @required
	 */
	private String cpsMain;
	
	/**
	 * 是否创建build.bat/xml
	 * 
	 * @parameter default-value="false"
	 * @required
	 */
	private String cpsAnt;
	
	/**
	 * 是否创建crypto.bat/sh
	 * 
	 * @parameter default-value="true"
	 * @required
	 */
	private String cpsCrypto;
	
	/**
	 * 是否创建autoDB.bat/sh
	 * 
	 * @parameter default-value="true"
	 * @required
	 */
	private String cpsAutodb;
	
	/**
	 * 是否创建startCheck.bat/sh
	 * 
	 * @parameter default-value="true"
	 * @required
	 */
	private String cpsStartcheck;
	
	/**
	 * 构造函数
	 */
	public MvnPackageMojo() {}
			
	/**
	 * Maven内部调用入口。
	 * 非Maven则通过构造实体调用此方法。
	 * @throws MojoExecutionException maven内部异常
	 */
	public void execute() 
			throws org.apache.maven.plugin.MojoExecutionException {
		
		// 从这里开始才能取到Maven配置，放在构造函数中无法获取
		try {
			initMavenConf();
		} catch (Exception e) {
			LogMgr.error("加载Maven配置失败,程序退出.", e);
			throw new org.apache.maven.plugin.MojoExecutionException(
					"加载Maven配置失败,程序退出", e);
		}
		
		// 根据pom配置获取主项目依赖包
		JarLoader.getInstn().loadMainPrjPom(project);
		
		// 执行脚本创建
		Core.getInstn().packageProject();
	}
	
	/**
	 * Maven调用时初始化配置。
	 * 把所有参数植入到Config，目的是统一接口。
	 */
	private void initMavenConf() throws Exception {
		LogMgr.info("正在初始化[脚本创建]配置...");
		Config.getInstn().setProjectName(project.getArtifactId());
		Config.getInstn().setProjectVersion(project.getVersion());
		Config.getInstn().setScriptType(scriptType);
		Config.getInstn().setMainClass(mainClass);
		Config.getInstn().setVersionClass(versionClass);
		Config.getInstn().setCharset(charset);
		Config.getInstn().setXms(xms);
		Config.getInstn().setXmx(xmx);
		Config.getInstn().setJdkParams(jdkParams);
		Config.getInstn().setLinuxLibPath(linuxLibPath);
		Config.getInstn().setWinLibPath(winLibPath);
		Config.getInstn().setLinuxCommonLibPath(linuxCommonLibPath);
		Config.getInstn().setWinCommonLibPath(winCommonLibPath);
		Config.getInstn().setLinuxMavenLibPath(linuxMavenLibPath);
		Config.getInstn().setWinMavenLibPath(winMavenLibPath);
		Config.getInstn().setPathPrefixMode(pathPrefixMode);
		
		Config.getInstn().setCpsMain(cpsMain);
		Config.getInstn().setCpsAnt(cpsAnt);
		Config.getInstn().setCpsCrypto(cpsCrypto);
		Config.getInstn().setCpsAutodb(cpsAutodb);
		Config.getInstn().setCpsStartcheck(cpsStartcheck);
		
		Config.getInstn().lockConf();	//锁定配置,禁止再修改
		LogMgr.info("[脚本创建]配置初始化完成:" + Config.getInstn().toPrintKV());
	}

}
